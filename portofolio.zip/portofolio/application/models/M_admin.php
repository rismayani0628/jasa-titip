<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model{

	function __construct(){
		parent::__construct();

	}
	function manualQuery($q)
	{
		return $this->db->query($q);
	}
	private $_table = "tb_produk";
	private $_table1 = "tb_slider";
	private $_table2 = "tb_tamu";

	public function tampil_user(){
		$id_user= $this->session->userdata('id_user');
		$q = $this->manualQuery("SELECT * From tb_user INNER JOIN user_role on `user_role`.`id` = `tb_user`.`role_id` WHERE `tb_user`.`id_user` = $id_user");
		return $q->result();
	}

	public function user_role(){
		$q = $this->manualQuery("SELECT * From user_role");
		return $q->result();
	}

	public function edit_userrole($id){
		$data = array(

			'role' => $this->input->post('role'),
			'team' => $this->input->post('team')
		);
		$this->db->where('id',$id);
		return $this->db->update('user_role',$data);
	}

	public function tambah_data($data,$table){
		$this->db->insert($table,$data);
	}

	public function service(){
		$q = $this->manualQuery("SELECT * From tb_service");
		return $q->result();
	}
	public function layanan(){
		$q = $this->manualQuery("SELECT * From tb_service where `tb_service`.`is_active`=1");
		return $q->result();
	}
	public function edit_service($id_service){
		$data = array(
			'nama_service' => $this->input->post('nama_service'),
			'icon' => $this->input->post('icon'),
			'keterangan' => $this->input->post('keterangan'),
		);
		$this->db->where('id_service',$id_service);
		return $this->db->update('tb_service',$data);
	}

	function status_service()
	{
		$id_service = $_REQUEST['$id_service'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_service', $id_service);
		return $this->db->update('tb_service', $data);
	}


	public function tampil_team(){
		$q = $this->manualQuery("SELECT * From tb_user INNER JOIN user_role on `tb_user`.`role_id` = `user_role`.`id` WHERE `user_role`.`team` = 'Ya' ");
		return $q->result();
	}
	public function tampil_customer(){
		$q = $this->manualQuery("SELECT * From tb_user INNER JOIN user_role on `tb_user`.`id_user` = `user_role`.`id` WHERE `user_role`.`team` = 'Tidak' ");
		return $q->result();
	}

	public function kategori_produk(){
		$q = $this->manualQuery("SELECT * From tb_kategori_produk");
		return $q->result();
	}

	public function edit_ktgr_produk($id_ktgr_produk){
		$data = array(
			'nm_ktgr_produk' => $this->input->post('nm_ktgr_produk')
		);
		$this->db->where('id_ktgr_produk',$id_ktgr_produk);
		return $this->db->update('tb_kategori_produk',$data);
	}

	public function produkaktif(){
		$q = $this->manualQuery("SELECT * From tb_produk INNER JOIN tb_kategori_produk on `tb_produk`.`id_ktgr_produk` = `tb_kategori_produk`.`id_ktgr_produk`  WHERE `tb_produk`.`is_active` = 1");
		return $q->result();
	}

	public function produk(){
		$q = $this->manualQuery("SELECT * From tb_produk INNER JOIN tb_kategori_produk on `tb_produk`.`id_ktgr_produk` = `tb_kategori_produk`.`id_ktgr_produk` ");
		return $q->result();
	}
	public function tampil_edit($where,$table){		
		return $this->db->get_where($table,$where);
	}

	function ubah_produk($where,$data,$table, $id_produk){
		$this->db->Select(['*','tb_produk.id_produk', 'tb_kategori_produk.id_ktgr_produk']);
		$this->db->from('tb_produk');
		$this->db->join('tb_kategori_produk', 'tb_produk.id_ktgr_produk = tb_kategori_produk.id_ktgr_produk');
		$this->db->where('tb_produk.id_produk', $id_produk);
		if($this->db->UPDATE('tb_produk', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	
	public function hitung_team(){
		$q = $this->manualQuery("SELECT COUNT(`tb_user`.`id_user`)as jumlahteam From tb_user INNER JOIN user_role on `user_role`.`id` = `tb_user`.`role_id` where  tb_user.role_id != 1");
		return $q->result();
	}

	public function hitung_sevice(){
		$q = $this->manualQuery("SELECT COUNT(`tb_service`.`id_service`)as jumlahservice From tb_service ");
		return $q->result();
	}

	public function hitung_produk(){
		$q = $this->manualQuery("SELECT COUNT(`tb_produk`.`id_produk`)as jumlahproduk From tb_produk INNER JOIN tb_kategori_produk on `tb_produk`.`id_ktgr_produk` = `tb_kategori_produk`.`id_ktgr_produk` ");
		return $q->result();
	}

	public function hitung_ktgrproduk(){
		$q = $this->manualQuery("SELECT COUNT(`tb_kategori_produk`.`id_ktgr_produk`)as jumlahktgrproduk From tb_kategori_produk");
		return $q->result();
	}

	public function delete($id){
		return $this->db->delete($this->_table, array("id_produk" => $id));
	}

	public function slider(){
		$q = $this->manualQuery("SELECT * From tb_slider");
		return $q->result();
	}
	public function slider1(){
		$q = $this->manualQuery("SELECT * From tb_slider where ket ='Slide 1' and is_active = 1");
		return $q->result();
	}

	public function slider2(){
		$q = $this->manualQuery("SELECT * From tb_slider where ket ='Slide 2' and is_active = 1");
		return $q->result();
	}
	public function slider3(){
		$q = $this->manualQuery("SELECT * From tb_slider where ket ='Slide 3' and is_active = 1");
		return $q->result();
	}

	public function delete_slider($id){
		return $this->db->delete($this->_table1, array("id_slider" => $id));
	}

	public function delete_tamu($id){
		return $this->db->delete($this->_table2, array("id_tamu" => $id));
	}

	function status_slider()
	{
		$id_slider = $_REQUEST['$id_slider'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_slider', $id_slider);
		return $this->db->update('tb_slider', $data);
	}

	function ubah_slider($where,$data,$table, $id_slider){
		$this->db->Select(['*','tb_slider.id_slider']);
		$this->db->from('tb_slider');
		$this->db->where('tb_slider.id_slider', $id_slider);
		if($this->db->UPDATE('tb_slider', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	

	function update_status()
	{
		$id_user = $_REQUEST['$id_user'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_user', $id_user);
		return $this->db->update('tb_user', $data);
	}

	public function tampil_teamaktif(){
		$q = $this->manualQuery("SELECT * From tb_user INNER JOIN user_role on `tb_user`.`role_id` = `user_role`.`id` WHERE `user_role`.`team` = 'Ya' and `tb_user`.`is_active` ='1' ");
		return $q->result();
	}

	function ubah_profilteam($where,$data,$table, $id_user){
		$this->db->Select(['*','tb_user.id_user', 'user_role.id']);
		$this->db->from('tb_user');
		$this->db->join('user_role', 'user_role.id = tb_user.role_id');
		$this->db->where('tb_user.id_user', $id_user);
		if($this->db->UPDATE('tb_user', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	


	function status_produk()
	{
		$id_produk = $_REQUEST['$id_produk'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_produk', $id_produk);
		return $this->db->update('tb_produk', $data);
	}

	// testimoni

	public function testimoni(){
		$q = $this->manualQuery("SELECT * From tb_testimoni");
		return $q->result();
	}

	function ubah_testimoni($where,$data,$table, $id_testimoni){
		$this->db->Select(['*','tb_testimoni.id_testimoni']);
		$this->db->from('tb_testimoni');
		$this->db->where('tb_testimoni.id_testimoni', $id_testimoni);
		if($this->db->UPDATE('tb_testimoni', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	

	function status_testimoni()
	{
		$id_testimoni = $_REQUEST['$id_testimoni'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_testimoni', $id_testimoni);
		return $this->db->update('tb_testimoni', $data);
	}

	public function testi_aktif(){
		$q = $this->manualQuery("SELECT * From tb_testimoni where is_active = 1");
		return $q->result();
	}

	// about

	public function about(){
		$q = $this->manualQuery("SELECT * From tb_about");
		return $q->result();
	}

	function ubah_about($where,$data,$table, $id_about){
		$this->db->Select(['*','tb_about.id_about']);
		$this->db->from('tb_about');
		$this->db->where('tb_about.id_about', $id_about);
		if($this->db->UPDATE('tb_about', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	

	function status_about()
	{
		$id_about = $_REQUEST['$id_about'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_about', $id_about);
		return $this->db->update('tb_about', $data);
	}

	public function about_aktif(){
		$q = $this->manualQuery("SELECT * From tb_about where is_active = 1");
		return $q->result();
	}

// patner

	public function patner(){
		$q = $this->manualQuery("SELECT * From tb_patner");
		return $q->result();
	}

	function status_patner()
	{
		$id_patner = $_REQUEST['$id_patner'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_patner', $id_patner);
		return $this->db->update('tb_patner', $data);
	}

	function ubah_patner($where,$data,$table, $id_patner){
		$this->db->Select(['*','tb_patner.id_patner']);
		$this->db->from('tb_patner');
		$this->db->where('tb_patner.id_patner', $id_patner);
		if($this->db->UPDATE('tb_patner', $data)){
			return true;
		}else{
			print_r($this->db->error());
		}
		exit();
	}	

	public function patner_aktif(){
		$q = $this->manualQuery("SELECT * From tb_patner where is_active = 1");
		return $q->result();
	}

	// Contact

	public function contact(){
		$q = $this->manualQuery("SELECT * From tb_contact");
		return $q->result();
	}

	public function edit_contact($id_contact){
		$data = array(

			'alamat' => $this->input->post('alamat'),
			'email' => $this->input->post('email'),
			'telp' => $this->input->post('telp'),
			'is_active' => $this->input->post('is_active'),
		);
		$this->db->where('id_contact',$id_contact);
		return $this->db->update('tb_contact',$data);
	}


	function status_contact()
	{
		$id_contact = $_REQUEST['$id_contact'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_contact', $id_contact);
		return $this->db->update('tb_contact', $data);
	}

	public function contact_aktif(){
		$q = $this->manualQuery("SELECT * From tb_contact WHERE tb_contact.is_active = 1 ");
		return $q->result();
	}

	public function tampil_pesan(){
		$q = $this->manualQuery("SELECT * From tb_tamu ");
		return $q->result();
	}

	// pengaturan
	public function pengaturan(){
		$q = $this->manualQuery("SELECT * From tb_konfigurasi ");
		return $q->result();
	}

	public function edit_pengaturan($id_konfigurasi){
		$data = array(
			'about' => $this->input->post('about'),
			'service' => $this->input->post('service'),
			'product' => $this->input->post('product'),
			'patner' => $this->input->post('patner'),
			'testimoni' => $this->input->post('testimoni'),
			'team' => $this->input->post('team'),
			'contact' => $this->input->post('contact'),
			'is_active' => $this->input->post('is_active'),
		);
		$this->db->where('id_konfigurasi',$id_konfigurasi);
		return $this->db->update('tb_konfigurasi',$data);
	}

	function status_pengaturan()
	{
		$id_konfigurasi = $_REQUEST['$id_konfigurasi'];
		$is_active = $_REQUEST['$is_active'];
		if ($is_active == 1) {

			$is_active = 0;
		}
		else{
			$is_active = 1;
		}
		$data = array(
			'is_active' =>$is_active

		);
		$this->db->where('id_konfigurasi', $id_konfigurasi);
		return $this->db->update('tb_konfigurasi', $data);
	}

	public function konfigurasi_judul(){
		$q = $this->manualQuery("SELECT * From tb_konfigurasi WHERE `tb_konfigurasi`.`is_active` ='1' ");
		return $q->result();
	}

}
