<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	//agar dapat diakses ke method manapun maka dibuatlah function_construct tersebut. 
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');

	}
	public function index()
	{	//agar ketika sudah login user tidak dapat membuka login melalui akss link.
		if ($this->session->userdata('username')) {
			redirect('Home');
		}
		//akhi
		$this->form_validation->set_rules('username', 'Username', 'required|trim');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');
		if ($this->form_validation->run()==false) {			
			$data['title'] = 'Login';
			$this->load->view('frontend/login', $data);
		} else{
			//jika validasinya sukses
			//agar methode ini gak kepanjangan maka di buatlah methode login namun akan dibuat secara privete yang hanya bisa diakses oleh kelas ini saja. dengan menambhkan _ untuk menandakan itu adalah ethod private
			$this->_login();
		}	 
		
	}

	private function _login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		//menggunakan query buildernya codeigniter 
		$user = $this->db->get_where('tb_user', ['username' =>$username])-> row_array(); //untuk mendapakan nilai satu baris
		//jika usernya ada
		if ($user) {
		//jika usernya aktif
			if ($user['is_active'] == 1) {
				//cek paaswordnya
				//password_verivy digunakan untuk menyamakan password yang diketikkandi login form  sama dengan password yang di hash
				if (password_verify($password, $user['password'])) {
					$data =[
						'username' =>$user['username'],
						'role_id' =>$user['role_id'],
						'id_user' =>$user['id_user']
					];
					//simpan datanya dalam session 
					$this->session->set_userdata($data);
					//arahkan ke controler admin kalau role_id 1 dan controler siswa kalau role_id 2 
					if($user['role_id'] == 1)
					{
						redirect('Admin');

					}
					if($user['role_id'] == 2)
					{
						redirect('Customer');
					}else{
						$this->session->set_flashdata('pesan', '<div class ="alert alert-danger" role="alert">Username dan Password salah</div>');
						redirect('auth');
					}
				}else{
					$this->session->set_flashdata('pesan', '<div class ="alert alert-danger" role="alert">Password Salah</div>');
					redirect('auth');
				}
			}else{
				$this->session->set_flashdata('pesan', '<div class ="alert alert-danger" role="alert">Username dan password tidak aktif</div>');
				redirect('auth');
			}
		}else{
			$this->session->set_flashdata('pesan', '<div class ="alert alert-danger" role="alert">Akun belum terdaftar</div>');
			redirect('auth');
		}
	}

	public function registrasi()
	{	
		$this->form_validation->set_rules('username', 'username', 'required|trim|is_unique[tb_user.username]', [
		'is_unique' => 'Username Sudah pernah didaftarkan']);//agar Username nya uniq dan ngecek apakah Username ini sudah ada di dalam database atau blm. dan trim digunakan untuk menghapus spasi.
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim');
		$this->form_validation->set_rules('ttl', 'TTL', 'required|trim');
		$this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required|trim');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules('hp', 'HP', 'required|trim');
		$this->form_validation->set_rules('link_twiter', 'Twiter', 'trim');
		$this->form_validation->set_rules('link_facebook', 'Facebook', 'trim');
		$this->form_validation->set_rules('link_instagram', 'Instagram', 'trim');
		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[4]|matches[password2]', [
			'matches' => 'password tidak sama!',
			'min_length' => 'Password terlalu pendek, Mininal 4 Karakter!' 
		]);
		$this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');		
		$this->form_validation->set_rules('role_id', 'Role', 'required|trim');

		//jika form validationyo gagal maka dia akan memproses tampilan registrasi
		if ($this->form_validation->run()==false) {
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['title'] = 'Registrasi';			
			$data['user_role']= $this->M_admin->user_role();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/registrasi', $data);
			$this->load->view('template/footer_backend',$data);
		}else{
			//kalau sukses maka data akan di insert kedalam database
			//htmlspecialchar dan true juga digunakan untuk menghindari xss
			$data=[
				'username'=>htmlspecialchars($this->input->post('username', true)),
				'password'=>password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
				'nama'=>htmlspecialchars($this->input->post('nama', true)),
				'ttl'=>htmlspecialchars($this->input->post('ttl', true)),
				'jk'=>htmlspecialchars($this->input->post('jk', true)),
				'alamat'=>htmlspecialchars($this->input->post('alamat', true)),
				'link_twiter'=>htmlspecialchars($this->input->post('link_twiter', true)),				
				'link_facebook'=>htmlspecialchars($this->input->post('link_facebook', true)),
				'link_instagram'=>htmlspecialchars($this->input->post('link_instagram', true)),
				'foto'=>'avatar.png',
				'is_active'=> 1,
				'role_id'=> htmlspecialchars($this->input->post('role_id', true)),
				'date_created'=> time()
			];
			$this->db->insert('tb_user', $data);
			$this->session->set_flashdata('pesan', '<div class ="alert alert-success" role="alert"> Selamat Akun anda telah terdaftar. Silahkan Login</div>');
			redirect('Admin/team');
		}
	}

	public function logout(){//membersihkan sesion
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('role_id');
		$this->session->set_flashdata('pesan', '<div class ="alert alert-success" role="alert">Berhasil logout</div>');
		redirect('Auth');
	}

	public function blocked(){
		$data['title'] = 'Blocked';		
		$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();		
		$this->load->view('admin/blocked',$data);
	}

}