<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

//agar dapat diakses ke seluruh kelas
	public function __construct()
	{
		parent::__construct();		
		$this->load->library('session'); //untuk membuat flashdata
	}

	public function index(){
		$data['title'] = 'Dagang Kita';
		$data['user'] = $this->db->get_where('tb_user',['username' => 
			$this->session->userdata('username')])->row_array();
		$data['slider1']= $this->M_admin->slider1();
		$data['slider2']= $this->M_admin->slider2();
		$data['slider3']= $this->M_admin->slider3();
		$data['service']= $this->M_admin->layanan();
		$data['testi']= $this->M_admin->testi_aktif();
		$data['s']= $this->M_admin->layanan();
		$data['team']= $this->M_admin->tampil_teamaktif();	
		$data['produk']= $this->M_admin->produkaktif();
		$data['about']= $this->M_admin->about_aktif();
		$data['patner']= $this->M_admin->patner_aktif();
		$data['contact']= $this->M_admin->contact_aktif();
		$data['konfigurasi']= $this->M_admin->konfigurasi_judul();
		$this->load->view('frontend/index', $data);
	}

	// Tamu

	public function add_tamu(){
		$nama_tamu = $this->input->post('nama_tamu');
		$email_tamu = $this->input->post('email_tamu');
		$subject = $this->input->post('subject');		
		$pesan = $this->input->post('pesan');		
		$tgl = $this->input->post('tgl');

		$data= array(
			'nama_tamu' => $nama_tamu,
			'email_tamu' => $email_tamu,
			'subject' => $subject,
			'pesan' => $pesan,		
			'tgl' =>date('Y-m-d H:i:s'),
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_tamu');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success alert-dismissible fade show" role="alert"> Pesan berhasil Dikirim.
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
			</div>');
		redirect('Home');
	}


}