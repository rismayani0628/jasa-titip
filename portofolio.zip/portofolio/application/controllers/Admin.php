<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

//agar dapat diakses ke seluruh kelas
	public function __construct()
	{
		parent::__construct();
		is_logged_in();
	}

	public function index()
	{
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Dashbord';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();					
			$data['hitung_produk']= $this->M_admin->hitung_produk();
			$data['hitung_ktgrproduk']= $this->M_admin->hitung_ktgrproduk();
			$data['hitung_team']= $this->M_admin->hitung_team();
			$data['hitung_sevice']= $this->M_admin->hitung_sevice();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend');
			$this->load->view('backend/index',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function profil(){
		{
			if($this->session->userdata('role_id') == 1){
				$data['title'] = 'Profil';		
				$data['id_user'] = $this->session->userdata('id_user');
				$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();
				$data['data']= $this->M_admin->tampil_user();		
				$this->load->view('template/head_backend',$data);
				$this->load->view('template/sidebar_backend');
				$this->load->view('backend/profil',$data);
				$this->load->view('template/footer_backend',$data);
			}
			else{
				redirect('Home');
			}
		}
	}

	public function edit_akun(){
		$data['title'] = 'Edit Akun';		
		$data['user'] = $this->db->get_where('tb_user',['username' =>
			$this->session->userdata('username')])->row_array();
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim');
		$this->form_validation->set_rules('ttl', 'Ttl', 'required|trim');
		$this->form_validation->set_rules('jk', 'JK', 'required|trim');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules('hp', 'Hp', 'required|trim');
		if ($this->form_validation->run()== false) {
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/edit_profil',$data);
			$this->load->view('template/footer_backend',$data);
		} else{
			$username = $this->input->post('username');
			$nama = $this->input->post('nama');
			$ttl = $this->input->post('ttl');
			$jk = $this->input->post('jk');
			$alamat = $this->input->post('alamat');
			$hp = $this->input->post('hp');
			//cek jika ada gambar yang akan di upload
			$upload_foto = $_FILES['foto'];

			if($upload_foto){

				$config['allowed_types'] = 'gif|jpg|png';
				$config['max_size']     = '10048';
				$config['upload_path'] = './assets/img/';
				
				$this->load->library('upload', $config);

				if ($this->upload->do_upload('foto')) {
					$old_foto = $data['user']['foto'];
					if ($old_foto != 'avatar.png') {
						unlink(FCPATH . 'assets/img/' . $old_foto);
					} 
					$new_foto = $this->upload->data('file_name');
					$this->db->set('foto', $new_foto);
				}else{
				// 	echo $this->upload->display_errors();

				}
			}
			$this->db->set('nama', $nama);
			$this->db->set('ttl', $ttl);
			$this->db->set('jk', $jk);
			$this->db->set('alamat', $alamat);
			$this->db->set('hp', $hp);
			$this->db->where('username', $username);
			//boleh pakai model jika tidak juga idak apa-apa.
			$this->db->UPDATE('tb_user');

			$this->session->set_flashdata('message','<div class="alert alert-success alert-sm" role="alert"> Biodata profil berhasil di ubah !</div>');
			redirect('Admin/profil');

		}

	}

	public function changepassword(){
		$data['title'] = 'Edit Profil';	
		$data['user'] = $this->db->get_where('tb_user',['username' => 
			$this->session->userdata('username')])->row_array();

		$this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
		$this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[4]|matches[new_password2]');
		$this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[4]|matches[new_password1]');

		if ($this->form_validation->run()==false) {
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/edit_profil',$data);
			$this->load->view('template/footer_backend',$data);
		}
		//mengatasi kalau validasinya lolos
		else{
			//pertama ngecek sama ngak current password dengan pasword yang ada di database.
			$current_password = $this->input->post('current_password');
			$new_password = $this->input->post('new_password1');
			if (!password_verify($current_password, $data['user']['password'])) {
				$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert"> Password sebelumnya tidak sesuai !</div>');
				redirect('Admin/edit_akun');
			}
			else{
				//kalau misalny apasswordnya bener, kita cek dulu password yang new sama ngak dengan password yang currentnya. karena password baru juga gak boleh sama dengan password lama.
				if ($current_password == $new_password ) {
					$this->session->set_flashdata('message','<div class="alert alert-danger" role="alert"> Password baru tidak boleh sama dengan Password saat ini !</div>');
					redirect('Admin/edit_akun');
				}
				//tapi kalau beda
				else{
					//password yang bener
					$password_hash = password_hash($new_password, PASSWORD_DEFAULT);

					$this->db->set('password', $password_hash);
					$this->db->where('username',$this->session->userdata('username'));
					$this->db->update('tb_user');

					$this->session->set_flashdata('message','<div class="alert alert-success alert-sm" role="alert">Password berhasil diubah!</div>');
					redirect('Admin/profil');
				}
			}
		}
	}

	public function user_role(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Hak Akses';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['data']= $this->M_admin->user_role();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/user_role',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function edit_userrole($id){
		$data = $this->M_admin->edit_userrole($id);
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Hak Akses Berhasil di ubah</div>');
		redirect('Admin/user_role');
	}

	public function add_userrole(){
		$role = $this->input->post('role');
		$team = $this->input->post('team');

		$data= array(
			'role' => $role,
			'team' => $team
		);
		// ini error
		$this->M_admin->tambah_data($data,'user_role');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Hak Kases Berhasil ditambah</div>');
		redirect('Admin/user_role');
	}

	// Service

	public function service(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Service';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['data']= $this->M_admin->service();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/service',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function add_service(){
		$id_user = $this->input->post('id_user');
		$nama_service = $this->input->post('nama_service');
		$icon = $this->input->post('icon');		
		$keterangan = $this->input->post('keterangan');
		$is_active = $this->input->post('is_active');

		$data= array(
			'nama_service' => $nama_service,
			'icon' => $icon,
			'keterangan' => $keterangan,
			'is_active' => $is_active
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_service');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Service / Layanan berhasil ditambah</div>');
		redirect('Admin/service');
	}

	public function edit_service($id_service){
		$data = $this->M_admin->edit_service($id_service);
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Service / Layanan Berhasil di ubah</div>');
		redirect('Admin/service');
	}

	public function status_service(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_service');
			$up_status = $this->tb_service->status_service();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Data tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> Data berhasil diubah</div>');
			}

		}
		return redirect('Admin/service');
	}


	// user

	public function user(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'User';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['customer']= $this->M_admin->tampil_customer();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/customer',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function team(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Team';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['team']= $this->M_admin->tampil_team();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/team',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	// Kategori Produk

	public function kategori_produk(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Kategori Produk';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['kategori_produk']= $this->M_admin->kategori_produk();	
			$data['hitung_produk']= $this->M_admin->hitung_produk();
			$data['hitung_ktgrproduk']= $this->M_admin->hitung_ktgrproduk();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/kategori_produk',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function add_ktgrproduk(){
		$nm_ktgr_produk = $this->input->post('nm_ktgr_produk');

		$data= array(
			'nm_ktgr_produk' => $nm_ktgr_produk,
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_kategori_produk');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Service / Layanan berhasil ditambah</div>');
		redirect('Admin/kategori_produk');
	}

	public function edit_ktgr_produk($id_ktgr_produk){
		$data = $this->M_admin->edit_ktgr_produk($id_ktgr_produk);
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data Berhasil di ubah</div>');
		redirect('Admin/kategori_produk');
	}

	// Produk

	public function produk(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Produk';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['produk']= $this->M_admin->produk();	
			$data['kategori_produk']= $this->M_admin->kategori_produk();
			$data['hitung_produk']= $this->M_admin->hitung_produk();
			$data['hitung_ktgrproduk']= $this->M_admin->hitung_ktgrproduk();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/produk',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function add_produk(){
		$id_ktgr_produk = $this->input->post('id_ktgr_produk');
		$nama_produk = $this->input->post('nama_produk');
		$deskripsi_produk = $this->input->post('deskripsi_produk');
		$link_produk = $this->input->post('link_produk');
		$is_active = $this->input->post('is_active');
		$brosur	 =$_FILES['brosur']['name'];
		if ($brosur = '') {} else{
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/brosur';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('brosur')) {
				echo "Image uploaded!";
			}else{
				$brosur=$this->upload->data('file_name');
			}
		}
		$data= array(
			'id_ktgr_produk' => $id_ktgr_produk,
			'nama_produk' => $nama_produk,
			'deskripsi_produk' => $deskripsi_produk,			
			'link_produk' => $link_produk,
			'is_active' => $is_active,
			'brosur' =>$brosur
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_produk');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/produk');
	}

	public function edit_produk($id_produk){
		$where = array('id_produk' => $id_produk);
		$data['user'] = $this->db->get_where('tb_user',['username' => 
			$this->session->userdata('username')])->row_array();				
		$data['edit_produk']= $this->M_admin->tampil_edit($where,'tb_produk')->result();
		$data['kategori_produk']= $this->M_admin->kategori_produk();		
		$data['hitung_produk']= $this->M_admin->hitung_produk();
		$data['hitung_ktgrproduk']= $this->M_admin->hitung_ktgrproduk();	
		$data['title'] = 'Edit Produk';
		$this->load->view('template/head_backend',$data);
		$this->load->view('template/sidebar_backend',$data);
		$this->load->view('backend/edit_produk',$data);
		$this->load->view('template/footer_backend',$data);
	}

	public function update_produk(){
		$id_produk			 =$this->input->post('id_produk');
		$id_ktgr_produk		 =$this->input->post('id_ktgr_produk');
		$nama_produk 		 =$this->input->post('nama_produk');
		$deskripsi_produk 	 =$this->input->post('deskripsi_produk');
		$link_produk 	 =$this->input->post('link_produk');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['brosur'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/brosur/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('brosur')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('brosur', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$data= array(
			'id_produk' => $id_produk,
			'id_ktgr_produk'	=>$id_ktgr_produk,
			'nama_produk' =>$nama_produk,
			'deskripsi_produk' =>$deskripsi_produk,
			'link_produk' =>$link_produk	
		);

		$where = array(
			'id_produk' => $id_produk
		);

		if($this->M_admin->ubah_produk($where,$data,'tb_produk', $id_produk)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/produk'),'refresh');		
		}

	}

	public function delete_produk($id=null){
		if (!isset($id)) show_404();
		if ($this->M_admin->delete($id)) {
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Data Berhasil Dihapus</div>');
			redirect(site_url('Admin/produk'));

		}
	}

	// Slider

	public function slider(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Slider';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['slider']= $this->M_admin->slider();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/slider',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function add_slider(){

		$ket = $this->input->post('ket');
		$is_active = $this->input->post('is_active');
		$gambar	 =$_FILES['gambar']['name'];
		if ($gambar = '') {} else{
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/slider';
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gambar')) {
				echo "Image uploaded!";
			}else{
				$gambar=$this->upload->data('file_name');
			}
		}
		$data= array(
			'ket' =>$ket,
			'is_active' =>$is_active,	
			'gambar' =>$gambar
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_slider');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/slider');
	}

	public function delete_slider($id=null){
		if (!isset($id)) show_404();
		if ($this->M_admin->delete_slider($id)) {
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Data Berhasil Dihapus</div>');
			redirect(site_url('Admin/slider'));

		}
	}

	public function status_slider(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_slider');
			$up_status = $this->tb_slider->status_slider();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">status slider tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> status slider berhasil diubah</div>');
			}

		}
		return redirect('Admin/slider');
	}

	public function update_slider(){
		$id_slider	 =$this->input->post('id_slider');
		$ket		 =$this->input->post('ket');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['gambar'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/slider/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('gambar')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('gambar', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$data= array(
			'id_slider' => $id_slider,
			'ket'	=>$ket
		);

		$where = array(
			'id_slider' => $id_slider
		);

		if($this->M_admin->ubah_slider($where,$data,'tb_slider', $id_slider)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/slider'),'refresh');		
		}

	}

	public function update_status(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_user');
			$up_status = $this->tb_user->update_status();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Update status user tidak berhasil</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> Update status user berhasil</div>');
			}

		}
		return redirect('Admin/team');
	}

	public function edit_profilteam($id_user){
		if($this->session->userdata('role_id') == 1){
			$where = array('id_user' => $id_user);
			$data['user'] = $this->db->get_where('tb_user',['username' => 
				$this->session->userdata('username')])->row_array();
			$data['profil_team']= $this->M_admin->tampil_edit($where,'tb_user')->result();				
			$data['user_role']= $this->M_admin->user_role();
			$data['title'] = 'Edit Profil';
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/edit_profilteam', $data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function update_profiltim(){
		$id_user			 =$this->input->post('id_user');
		$username		 =$this->input->post('username');
		$password 		 =$this->input->post('password');
		$nama 	 =$this->input->post('nama');
		$ttl 	 =$this->input->post('ttl');		
		$jk 	 =$this->input->post('jk');
		$alamat 	 =$this->input->post('alamat');
		$hp 	 =$this->input->post('hp');
		$link_twiter 	 =$this->input->post('link_twiter');
		$link_facebook 	 =$this->input->post('link_facebook');
		$link_instagram 	 =$this->input->post('link_instagram');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['foto'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('foto')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('foto', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$is_active 	 =$this->input->post('is_active');		
		$role_id 	 =$this->input->post('role_id');	
		$date_created 	 =$this->input->post('date_created');

		$data= array(
			'id_user' => $id_user,
			'username'	=>$username,
			'password' =>$password,
			'nama' =>$nama,
			'ttl' =>$ttl,
			'jk' =>$jk,	
			'alamat' =>$alamat,
			'hp' =>$hp,
			'link_twiter' =>$link_twiter,
			'link_facebook' =>$link_facebook,
			'link_instagram' =>$link_instagram,
			'is_active' =>$is_active,
			'role_id' =>$role_id,
			'date_created' =>$date_created
		);

		$where = array(
			'id_user' => $id_user
		);

		if($this->M_admin->ubah_profilteam($where,$data,'tb_user', $id_user)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/team'),'refresh');		
		}

	}

	public function status_produk(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_produk');
			$up_status = $this->tb_produk->status_produk();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">status produk tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> status produk berhasil diubah</div>');
			}

		}
		return redirect('Admin/produk');
	}

	// Testimoni

	public function testimoni(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Testimoni';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['testimoni']= $this->M_admin->testimoni();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/testimoni',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function add_testimoni(){
		$nama_testi = $this->input->post('nama_testi');
		$pekerjaan = $this->input->post('pekerjaan');
		$deskripsi_testi = $this->input->post('deskripsi_testi');
		$is_active = $this->input->post('is_active');
		$foto_testi	 =$_FILES['foto_testi']['name'];
		if ($foto_testi = '') {} else{
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/foto_testi';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('foto_testi')) {
				echo "Image uploaded!";
			}else{
				$foto_testi=$this->upload->data('file_name');
			}
		}
		$data= array(
			'nama_testi' => $nama_testi,
			'pekerjaan' => $pekerjaan,
			'deskripsi_testi' => $deskripsi_testi,
			'is_active' => $is_active,
			'foto_testi' =>$foto_testi
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_testimoni');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/testimoni');
	}

	public function edit_testimoni($id_testimoni){
		$where = array('id_testimoni' => $id_testimoni);
		$data['user'] = $this->db->get_where('tb_user',['username' => 
			$this->session->userdata('username')])->row_array();				
		$data['edit_testi']= $this->M_admin->tampil_edit($where,'tb_testimoni')->result();
		$data['title'] = 'Edit Testimoni';
		$this->load->view('template/head_backend',$data);
		$this->load->view('template/sidebar_backend',$data);
		$this->load->view('backend/edit_testimoni',$data);
		$this->load->view('template/footer_backend',$data);
	}

	public function update_testi(){
		$id_testimoni			 =$this->input->post('id_testimoni');
		$nama_testi		 =$this->input->post('nama_testi');
		$pekerjaan 		 =$this->input->post('pekerjaan');
		$deskripsi_testi 	 =$this->input->post('deskripsi_testi');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['foto_testi'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/foto_testi/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('foto_testi')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('foto_testi', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$data= array(
			'id_testimoni' => $id_testimoni,
			'nama_testi'	=>$nama_testi,
			'pekerjaan' =>$pekerjaan,
			'deskripsi_testi'=>$deskripsi_testi
		);

		$where = array(
			'id_testimoni' => $id_testimoni
		);

		if($this->M_admin->ubah_testimoni($where,$data,'tb_testimoni', $id_testimoni)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/testimoni'),'refresh');		
		}

	}

	public function status_testimoni(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_testimoni');
			$up_status = $this->tb_testimoni->status_testimoni();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert"> User Status not Update Successfully</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> User Status Update Successfully</div>');
			}

		}
		return redirect('Admin/testimoni');
	}

	// About

	public function about(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'About';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['about']= $this->M_admin->about();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/about',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function add_about(){
		$judul = $this->input->post('judul');
		$isi = $this->input->post('isi');
		$is_active = $this->input->post('is_active');
		$gambar_about	 =$_FILES['gambar_about']['name'];
		if ($gambar_about = '') {} else{
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gambar_about')) {
				echo "Image uploaded!";
			}else{
				$gambar_about=$this->upload->data('file_name');
			}
		}
		$data= array(
			'judul' => $judul,
			'isi' => $isi,
			'is_active' => $is_active,
			'gambar_about' =>$gambar_about
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_about');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/about');
	}

	public function edit_about($id_about){
		$where = array('id_about' => $id_about);
		$data['user'] = $this->db->get_where('tb_user',['username' => 
			$this->session->userdata('username')])->row_array();				
		$data['edit_about']= $this->M_admin->tampil_edit($where,'tb_about')->result();
		$data['title'] = 'Edit';
		$this->load->view('template/head_backend',$data);
		$this->load->view('template/sidebar_backend',$data);
		$this->load->view('backend/edit_about',$data);
		$this->load->view('template/footer_backend',$data);
	}

	public function update_about(){
		$id_about			 =$this->input->post('id_about');
		$judul		 =$this->input->post('judul');
		$isi 		 =$this->input->post('isi');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['gambar_about'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('gambar_about')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('gambar_about', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$data= array(
			'id_about' => $id_about,
			'judul'	=>$judul,
			'isi' =>$isi
		);

		$where = array(
			'id_about' => $id_about
		);

		if($this->M_admin->ubah_about($where,$data,'tb_about', $id_about)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/about'),'refresh');		
		}

	}

	public function status_about(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_about');
			$up_status = $this->tb_about->status_about();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">  Status not Update Successfully</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> Status Update Successfully</div>');
			}

		}
		return redirect('Admin/about');
	}


	// patner

	public function patner(){
		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Patner';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['patner']= $this->M_admin->patner();
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/patner',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function add_patner(){

		$nm_instansi = $this->input->post('nm_instansi');
		$link_patner = $this->input->post('link_patner');
		$is_active = $this->input->post('is_active');
		$gambar_patner	 =$_FILES['gambar_patner']['name'];
		if ($gambar_patner = '') {} else{
			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/patner';

			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('gambar_patner')) {
				echo "Image uploaded!";
			}else{
				$gambar_patner=$this->upload->data('file_name');
			}
		}
		$data= array(
			'nm_instansi' =>$nm_instansi,
			'link_patner' =>$link_patner,
			'is_active' =>$is_active,	
			'gambar_patner' =>$gambar_patner
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_patner');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/patner');
	}

	public function status_patner(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_patner');
			$up_status = $this->tb_patner->status_patner();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">status slider tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> status slider berhasil diubah</div>');
			}

		}
		return redirect('Admin/patner');
	}

	public function update_patner(){
		$id_patner	 =$this->input->post('id_patner');
		$nm_instansi		 =$this->input->post('nm_instansi');
		$link_patner		 =$this->input->post('link_patner');
		//cek jika ada gambar yang akan di upload
		$upload_foto = $_FILES['gambar_patner'];
		if($upload_foto){

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']     = '2048';
			$config['upload_path'] = './assets/img/patner/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('gambar_patner')) {

				$new_foto = $this->upload->data('file_name');
				$this->db->set('gambar_patner', $new_foto);
			}else{
				// echo $this->upload->display_errors();
			}
		}
		$data= array(
			'id_patner' => $id_patner,
			'nm_instansi'	=>$nm_instansi,
			'link_patner'	=>$link_patner
		);

		$where = array(
			'id_patner' => $id_patner
		);

		if($this->M_admin->ubah_patner($where,$data,'tb_patner', $id_patner)){
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">  Data Berhasil di Ubah</div>');
			redirect(base_url('Admin/patner'),'refresh');		
		}

	}


	// Contact

	public function contact(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Contact';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['contact']= $this->M_admin->contact();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/contact',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}
	public function add_contact(){
		$alamat = $this->input->post('alamat');
		$email = $this->input->post('email');
		$telp = $this->input->post('telp');		
		$is_active = $this->input->post('is_active');

		$data= array(
			'alamat' => $alamat,
			'email' => $email,
			'telp' => $telp,
			'is_active' => $is_active
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_contact');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> Data berhasil ditambah</div>');
		redirect('Admin/contact');
	}

	public function edit_contact($id_contact){
		$data = $this->M_admin->edit_contact($id_contact);
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data Berhasil di ubah</div>');
		redirect('Admin/contact');
	}

	public function status_contact(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_contact');
			$up_status = $this->tb_contact->status_contact();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">status slider tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> status slider berhasil diubah</div>');
			}

		}
		return redirect('Admin/contact');
	}

	// pesan

	public function pesan(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Buku Tamu';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['pesan']= $this->M_admin->tampil_pesan();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/pesan',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	// Pengaturan

	public function pengaturan(){

		if($this->session->userdata('role_id') == 1){
			$data['title'] = 'Pengturan';		
			$data['user'] = $this->db->get_where('tb_user',['username' => $this->session->userdata('username')])->row_array();	
			$data['data']= $this->M_admin->pengaturan();	
			$this->load->view('template/head_backend',$data);
			$this->load->view('template/sidebar_backend',$data);
			$this->load->view('backend/pengaturan',$data);
			$this->load->view('template/footer_backend',$data);
		}
		else{
			redirect('Home');
		}
	}

	public function add_pengaturan(){
		$about = $this->input->post('about');
		$service = $this->input->post('service');
		$product = $this->input->post('product');		
		$patner = $this->input->post('patner');
		$testimoni = $this->input->post('testimoni');
		$team = $this->input->post('team');		
		$contact = $this->input->post('contact');
		$is_active = $this->input->post('is_active');

		$data= array(
			'about' => $about,
			'service' => $service,
			'product' => $product,
			'patner' => $patner,
			'testimoni' => $testimoni,
			'team' => $team,
			'contact' => $contact,
			'is_active' => $is_active,
		);
		// ini error
		$this->M_admin->tambah_data($data,'tb_konfigurasi');
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data berhasil ditambah</div>');
		redirect('Admin/pengaturan');
	}

	public function edit_pengaturan($id_konfigurasi){
		$data = $this->M_admin->edit_pengaturan($id_konfigurasi);
		$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert">Data Berhasil di ubah</div>');
		redirect('Admin/pengaturan');
	}

	public function status_pengaturan(){
		if(isset($_REQUEST['$is_active']))
		{
			$this->load->model('M_admin','tb_konfigurasi');
			$up_status = $this->tb_konfigurasi->status_pengaturan();

			if ($up_status = 0) {

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Data tidak berhasil diubah</div>');
			}else{

				$this->session->set_flashdata('message', '<div class="alert alert-sm alert-success" role="alert"> Data berhasil diubah</div>');
			}

		}
		return redirect('Admin/pengaturan');
	}

	public function delete_tamu($id=null){
		if (!isset($id)) show_404();
		if ($this->M_admin->delete_tamu($id)) {
			$this->session->set_flashdata('message', '<div class="alert alert-sm alert-danger" role="alert">Data Berhasil Dihapus</div>');
			redirect(site_url('Admin/pesan'));

		}
	}

}