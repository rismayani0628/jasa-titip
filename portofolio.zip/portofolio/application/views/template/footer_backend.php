<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Dagang</b> Kita
  </div>
  <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://almsaeedstudio.com">Kreasi Anak Bengkalis</a>.</strong>
</footer>

<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url() ?>assets/backend/plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo base_url() ?>assets/backend/bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url() ?>assets/backend/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>assets/backend/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url() ?>assets/backend/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url() ?>assets/backend/plugins/fastclick/fastclick.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url() ?>assets/backend/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url() ?>assets/backend/dist/js/demo.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url() ?>assets/backend/plugins/select2/select2.full.min.js"></script>
<!-- page script -->
<!-- Logout Modal-->
<div class="modal fade" id="Modallogout" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header btn-danger">
        <h5 class="modal-title" id="exampleModalLabel">Yakin Ingin Keluar?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Apakah Anda akan keluar dari aplikasi ?</div>
      <div class="modal-footer">
        <a class="btn btn-sm btn-flat btn-danger" href="<?php echo base_url('Auth/logout') ?>">Logout</a>
      </div>
    </div>
  </div>
</div>
<!--   akhir modal logout -->

<!-- Logout Delete Confirmation-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-red">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Data yang dihapus tidak akan bisa dikembalikan.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary btn-icon-split btn-sm" type="button" data-dismiss="modal">
          <span class="icon text-white-50">
            <i class="fas fa-times"></i>
          </span>
          <span class="text">Cancel</span></button>
          <a id="btn-delete" class="btn btn-danger btn-icon-split btn-sm" href="#"><span class="icon text-white-50">
            <i class="fas fa-trash"></i>
          </span>
          <span class="text">Delete</span></a>
        </div>
      </div>
    </div>
  </div>
  <!--   akhir modal delete -->
  <script>
    $(function () {
      $("#example1").DataTable({
        "scrollX": true
      });
      $('#example2').DataTable({
        "paging": true,
        "scrollX": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false
      });
    });
  </script>
  <script>
//script untuk menampilkan ketika mengganti foto profile
$('.custom-file-input').on('change', function(){
  let fileName = $(this).val().split('\\').pop();
  $(this).next('.custom-file-label').addClass("selected").html(fileName);
});

$(function () {
//Initialize Select2 Elements
$(".select2").select2();
});
</script>
<!-- akhir script -->
</body>
</html>
