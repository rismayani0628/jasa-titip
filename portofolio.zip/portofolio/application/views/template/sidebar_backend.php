      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url('assets/img/'). $user['foto'];?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php  echo $user['nama'] ?></p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">Administrator</li>
            <li class="treeview">
              <a href="#">
                <i class="nav-icon fas fa-tachometer-alt"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url('Admin') ?>"><i class="fa fa-desktop"></i> Dashboard</a></li>
                <li><a href="<?php echo base_url('Admin/profil')?>"><i class="fa fa-user"></i> Profil</a></li>
              </ul>
            </li>            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-folder-open"></i>
                <span>Data Master</span><i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">                
                <li><a href="<?php echo base_url('Admin/pengaturan') ?>"><i class="fa fa-wrench"></i>Konfigurasi Header</a></li>
                <li><a href="<?php echo base_url('Admin/slider') ?>"><i class="fa fa-sliders"></i> Slider</a></li>
                <li><a href="<?php echo base_url('Admin/about') ?>"><i class="fa fa-address-card"></i> About</a></li>
                <li><a href="<?php echo base_url('Admin/service') ?>"><i class="fa fa-desktop"></i> Service</a></li>
                <li><a href="<?php echo base_url('Admin/kategori_produk') ?>"><i class="fa fa-cart-plus"></i> Product</a></li>                
                <li><a href="<?php echo base_url('Admin/patner') ?>"><i class="fa fa-desktop"></i> Patner</a></li>
                <li><a href="<?php echo base_url('Admin/testimoni') ?>"><i class="fa fa-send"></i> Testimoni</a></li>
                <li><a href="<?php echo base_url('Admin/user') ?>"><i class="fa fa-user-plus"></i> Team</a></li>
                <li><a href="<?php echo base_url('Admin/contact') ?>"><i class="fa fa-tty"></i> Contact</a></li>
              </ul>
            </li>            
            <li><a href="<?php echo base_url('Admin/pesan') ?>"><i class="fa fa-envelope"></i> Pesan</a></li>
            <li><a href="<?php echo base_url('Admin/user_role') ?>"><i class="fa fa-cog"></i> Hak Akses</a></li>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>