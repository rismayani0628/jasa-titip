      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <section class="content-header">
          <div class="row">
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                  <h4><strong>Data Customer</strong></h4>
                </div>
                <a href="<?php echo base_url('Admin/user') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h4><strong>Data Team</strong></h4>
                </div>
                <a  href="<?php echo base_url('Admin/team') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
        </section>
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header bg-blue">
                  <h3 class="box-title">Data Customer</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>TTL</th>
                        <th>JK</th>
                        <th>Alamat</th>
                        <th>HP</th>
                        <th>Akses</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php  $no = 1;
                     foreach ($customer as $customer):?>
                      <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $customer->nama; ?></td>
                        <td><?php echo $customer->ttl; ?></td>
                        <td><?php echo $customer->jk; ?></td>
                        <td><?php echo $customer->alamat; ?></td>
                        <td><?php echo $customer->hp; ?></td>
                        <td><?php echo $customer->role; ?></td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
