<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Contact
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('Admin') ?>"><i class="fa fa-desktop"></i> Home</a></li>
      <li class="active">Service</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">      
      <?php echo $this->session->flashdata('message');?>
      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header bg-blue">
          <h3 class="box-title text-light">Tambah Data</h3>
        </div>
          <div class="box-body box-profile">
            <form method="post" action="<?php echo base_url().'Admin/add_contact' ?>">
              <div class="form-group">
                <input type="hidden" name="is_active" class="form-control" value="1" readonly>
                <input type="text" name="alamat" class="form-control" placeholder="Alamat" required>
              </div>
               <div class="form-group">
                <input type="text" name="email" class="form-control" placeholder="Email" required>
              </div>
              <div class="form-group">
                <input type="number" name="telp" class="form-control" placeholder="Telephon" required>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
      </div>
      <!-- Profile Image -->

      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header bg-blue">
            <h3 class="box-title">Form Contact</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-condensed table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Alamat</th>
                  <th>Email</th>
                  <th>Telp</th>
                  <th>Aktivasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no = 1;
                foreach ($contact as $data):?>
                  <tr>
                    <td><?php echo $no++?></td>
                    <td><?php echo $data->alamat?></td>
                    <td><?php echo $data->email?></td>
                    <td><?php echo $data->telp?></td>
                    <td>
                      <?php  
                      $is_active = $data->is_active;
                      if ($is_active == 1) {
                        ?>
                        <a href="status_contact?$id_contact=<?php echo $data->id_contact;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                        <?php
                      }
                      else{
                        ?>
                        <a href="status_contact?$id_contact=<?php echo $data->id_contact;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                        <?php
                      }
                      ?>
                    </td>

                    <td><a href="javascript:void(0)" data-toggle="modal" data-target="#editcontact<?php echo $data->id_contact ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                    </td>
                  </tr>
                </tbody>
                  <!-- Modal edit jenjang -->
                  <div class="modal fade" id="editcontact<?php echo $data->id_contact ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header bg-primary">
                          <h4 class="modal-title" id="exampleModalLabel">Form Edit</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <form method="post" action="<?php echo base_url().'Admin/edit_contact/'.$data->id_contact ?>">
                            <div class="form-group">
                              <label>Service</label>
                              <input type="text" name="alamat" class="form-control" value="<?= $data->alamat; ?>">
                              <input type="hidden" name="id_contact" class="form-control" value="<?= $data->id_contact; ?>">
                              <input type="hidden" name="is_active" class="form-control" value="<?= $data->is_active; ?>">
                            </div>
                            <div class="form-group">
                              <label>Icon</label>
                              <input type="text" name="email" class="form-control" value="<?= $data->email; ?>">
                            </div>
                            <div class="form-group">
                              <label>Telephon</label>
                              <input type="text" name="telp" class="form-control" value="<?= $data->telp; ?>">
                            </div>
                            <button type="submit" class="btn btn-success btn-icon-split btn-sm" value="save">
                              <span class="icon text-white-50">
                                <i class="fas fa-check"></i>
                              </span>
                              <span class="text">Edit</span> 
                            </button>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Akhir modal edit jenjang -->
                <?php endforeach; ?>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div>
  </section>
</div>
