      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
       <section class="content-header">
        <div class="row">
          <?php foreach ($hitung_ktgrproduk as $hitung_ktgrproduk) { ?>
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                  <h4><strong>Kategori Produk : <?php  echo $hitung_ktgrproduk->jumlahktgrproduk; ?></strong></h4>
                </div>
                <a href="<?php echo base_url('Admin/kategori_produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          <?php   } ?>

          <!--   produk -->
          <?php foreach ($hitung_produk as $hitung_produk) { ?>
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h4><strong>Produk : <?php  echo $hitung_produk->jumlahproduk; ?></strong></h4>
                </div>
                <a  href="<?php echo base_url('Admin/produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          <?php   } ?>
        </div><!-- /.row -->
      </section>
      <!-- Main content -->
      <section class="content">
        <div class="box">
         <div class="box box-primary">
          <div class="box-header with-border">
           <a class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" href="<?php echo base_url("Admin/produk") ?>" class="m-0 font-weight-bold text-light"><i class="fas fa-fw fa-arrow-left"></i> Kembali</a>
         </div><!-- /.box-header -->
         <div class="box-body">
          <?php foreach($edit_produk as $data){ ?>
            <?php echo form_open_multipart('Admin/update_produk');?>
            <div class="form-group">
              <label for="id_ktgr_produk">Kategori Produk *</label>
              <div class="id_ktgr_produk">
                <select name="id_ktgr_produk" class="form-control select2">
                  <?php foreach ($kategori_produk as $k)
                  {
                    if($k->id_ktgr_produk == $data->id_ktgr_produk){
                      echo '<option selected value="'.$k->id_ktgr_produk.'">'.$k->nm_ktgr_produk.' </option>';}
                      else{
                        echo '<option value="'.$k->id_ktgr_produk.'">'.$k->nm_ktgr_produk.'</option>';           
                      }
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label>Produk</label>
                <input type="text" name="nama_produk" class="form-control" value="<?= $data->nama_produk; ?>">
                <input type="hidden" name="id_produk" class="form-control" value="<?= $data->id_produk; ?>">
              </div>
              <div class="form-group">
                <label>Deskripsi Produk</label>
          <textarea class="form-control" name="deskripsi_produk" placeholder="Deskripsi Produk" required><?= $data->deskripsi_produk; ?></textarea>
              </div>
               <div class="form-group">
                <label>Link Produk</label>
                <input type="text" name="link_produk" class="form-control" value="<?= $data->link_produk; ?>">
              </div>
              <div class="form-group row">
                <div class="col-sm-12">
                  <div class="row">
                    <div class="col-sm-3">
                      <img src="<?= base_url('assets/brosur/') . $data->brosur?>" class="img-thumbnail">
                    </div>
                    <div class="col-sm-9">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="brosur">
                        <label class="custom-file-label" for="brosur">Choose file</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <button type="save" class="btn btn-primary btn-icon-split btn-sm" value="save">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Edit</span> 
              </button>
            </form>
          <?php } ?> 
        </div>
      </div> <!-- /.box-body -->
    </div> <!-- /.box -->
  </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
