      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
      <!-- Main content -->
      <section class="content">
        <div class="box">
         <div class="box box-primary">
          <div class="box-header with-border">
           <a class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" href="<?php echo base_url("Admin/testimoni") ?>" class="m-0 font-weight-bold text-light"><i class="fas fa-fw fa-arrow-left"></i> Kembali</a>
         </div><!-- /.box-header -->
         <div class="box-body">
          <?php foreach($edit_testi as $data){ ?>
            <?php echo form_open_multipart('Admin/update_testi');?>
              <div class="form-group">
                <label>Nama Tester</label>
                <input type="text" name="nama_testi" class="form-control" value="<?= $data->nama_testi; ?>">
                <input type="hidden" name="id_testimoni" class="form-control" value="<?= $data->id_testimoni; ?>">
              </div>
              <div class="form-group">
                <label>Pekerjaan</label>
                <input type="text" name="pekerjaan" class="form-control" value="<?= $data->pekerjaan; ?>">
              </div>
              <div class="form-group">
                <label>Deskripsi</label>                
                <textarea class="form-control" name="deskripsi_testi" placeholder="Deskripsi Produk" required><?= $data->deskripsi_testi; ?></textarea>
              </div>
              <div class="form-group row">
                <div class="col-sm-12">
                  <div class="row">
                    <div class="col-sm-3">
                      <img src="<?= base_url('assets/img/foto_testi/') . $data->foto_testi?>" class="img-thumbnail">
                    </div>
                    <div class="col-sm-9">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="foto_testi">
                        <label class="custom-file-label" for="foto_testi">Choose file</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <button type="save" class="btn btn-primary btn-icon-split btn-sm" value="save">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Edit</span> 
              </button>
            </form>
          <?php } ?> 
        </div>
      </div> <!-- /.box-body -->
    </div> <!-- /.box -->
  </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
