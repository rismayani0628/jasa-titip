      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->        
        <?php echo $this->session->flashdata('message');?>
        <section class="content">
          <div class="box box-primary">
            <div class="box-body box-profile">
              <?php echo form_open_multipart('Admin/add_about');?>
              <div class="form-group">
                <input type="text" name="judul"  id="judul" class="form-control" required placeholder="Judul">
                <input type="hidden" name="is_active"  id="is_active" class="form-control" required value="1" readonly>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="isi" placeholder="Deskripsi About" required></textarea>
              </div>
              <div class="form-group">
                <div class="row-md-10">
                  <label>Gambar</label>
                  <div class="custom-file form-control">
                    <input type="file" class="custom-file-input" id="gambar_about" name="gambar_about">
                  </div>                        
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
        <!-- general form elements disabled -->
        
        <div class="box">
         <div class="box box-primary">
          <div class="box-header with-border  bg-blue">
            <h3 class="box-title">About</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Foto</th>
                  <th>Judul</th>
                  <th>Deskripsi</th>
                  <th>Aktivasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php  $no = 1;
               foreach ($about as $about):?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td>
                    <?php if($about->gambar_about == ' '){?>
                      <?php echo $about->gambar_about?>
                    <?php } if($about->gambar_about != ''){?>
                      <a href="javascript:void(0)" data-toggle="modal" data-target="#lihat<?php echo $about->id_about ?>"><img src="<?= base_url('assets/img/').$about->gambar_about ?>" class="img-fluid" height="100px" width="100px"/>
                      </a>
                    <?php }?>
                  </td>
                  <td><?php echo $about->judul; ?></td>
                  <td><?php echo $about->isi; ?></td>
                   <td>
                    <?php  
                    $is_active = $about->is_active;
                    if ($is_active == 1) {
                      ?>
                      <a href="status_about?$id_about=<?php echo $about->id_about;?>&$is_active=<?php echo $about->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                      <?php
                    }
                    else{
                      ?>
                      <a href="status_about?$id_about=<?php echo $about->id_about;?>&$is_active=<?php echo $about->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                      <?php
                    }
                    ?>
                  </td>
                  <td><?php echo anchor('Admin/edit_about/'.$about->id_about, '<div class="btn btn-circle btn-sm btn-primary"><i class="fas fa-edit"></i></div>') ?></a>
                  </td>
                </tr>
                <!-- modal tampil gamabr -->
                <div class="modal fade" id="lihat<?php echo $about->id_about ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header bg-green">
                        <h4 class="modal-title text-white" id="exampleModalLabel">Foto</h4>
                        <button type="button" class="close bg-success" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="post" action="<?php echo base_url().'Admin/about' ?>">
                          <div class="form-group">
                            <img src="<?= base_url('assets/img/').$about->gambar_about ?>" class="img-fluid" width="500px" height="500px" />
                          </div>

                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- akhir moodel tampil gambar -->
              <?php endforeach; ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->

  <script>
    function deleteConfirm(url){
      $('#btn-delete').attr('href', url);
      $('#deleteModal').modal();
    }
  </script>
