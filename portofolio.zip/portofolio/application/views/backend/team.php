      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="row">            
            <?php echo $this->session->flashdata('message');?>
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                  <h4><strong>Data Customer</strong></h4>
                </div>
                <a href="<?php echo base_url('Admin/user') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h4><strong>Data Team</strong></h4>
                </div>
                <a  href="<?php echo base_url('Admin/add_team') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
        </section>
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header bg-green">
                  <h3 class="box-title"><a href="<?php echo base_url('Auth/registrasi') ?>" class="btn btn-sm btn-success"><i class="fa fas fa-user-plus"> Add Team</i></a></h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>TTL</th>
                        <th>JK</th>
                        <th>Alamat</th>
                        <th>HP</th>
                        <th>Keahlian</th>
                        <th>Status</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                     <?php  $no = 1;
                     foreach ($team as $team):?>
                      <tr>
                        <td><?php echo $no++ ?></td>
                        <td>
                          <?php if($team->foto == ' '){?>
                            <?php echo $team->foto?>
                          <?php } if($team->foto != ''){?>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#lihat<?php echo $team->id_user ?>"><img src="<?= base_url('assets/img/').$team->foto ?>" class="img-fluid" height="100px" width="100px"/>
                            </a>
                          <?php }?>
                        </td>
                        <td><?php echo $team->username; ?></td>
                        <td><?php echo $team->nama; ?></td>
                        <td><?php echo $team->ttl; ?></td>
                        <td> <?php if($team->jk == 'P' ){?>
                          Perempuan                      
                        <?php } if($team->jk == 'L'){?> 
                         Laki-Laki
                       <?php }?>
                     </td>
                     <td><?php echo $team->alamat; ?></td>
                     <td><?php echo $team->hp; ?></td>
                     <td><?php echo $team->role; ?></td>
                     <td>
                      <?php  
                      $is_active = $team->is_active;
                      if ($is_active == 1) {
                        ?>
                        <a href="update_status?$id_user=<?php echo $team->id_user;?>&$is_active=<?php echo $team->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                        <?php
                      }
                      else{
                        ?>
                        <a href="update_status?$id_user=<?php echo $team->id_user;?>&$is_active=<?php echo $team->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                        <?php
                      }
                      ?>
                    </td>
                    <td> 
                      <a href="<?php echo base_url('admin/edit_profilteam/').$team->id_user ?>" class="btn btn-primary btn-icon-split btn-sm float-sm-right">
                        <span class="icon text-white-50">
                          <i class="fas fa-user-edit"></i>
                        </span>
                        <span class="text">Edit</span>                    
                      </a>
                    </td>
                  </tr>

                  <!-- modal tampil gamabr -->
                  <div class="modal fade" id="lihat<?php echo $team->id_user ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header bg-green">
                          <h4 class="modal-title text-white" id="exampleModalLabel">Detail Foto</h4>
                          <button type="button" class="close bg-success" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <form method="post" action="<?php echo base_url().'Admin/team' ?>">
                            <div class="form-group">
                              <img src="<?= base_url('assets/img/').$team->foto ?>" class="img-fluid" height="500px" widht="500px"/>
                            </div>

                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- akhir moodel tampil gambar -->
                <?php endforeach; ?>
              </tbody>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div><!-- /.content-wrapper -->
