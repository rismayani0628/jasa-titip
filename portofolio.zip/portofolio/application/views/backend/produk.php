      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <section class="content-header">
          <div class="row">
            <?php foreach ($hitung_ktgrproduk as $hitung_ktgrproduk) { ?>
              <div class="col-lg-6 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-blue">
                  <div class="inner">
                    <h4><strong>Kategori Produk : <?php  echo $hitung_ktgrproduk->jumlahktgrproduk; ?></strong></h4>
                  </div>
                  <a href="<?php echo base_url('Admin/kategori_produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div><!-- ./col -->
            <?php   } ?>

            <!--   produk -->
            <?php foreach ($hitung_produk as $hitung_produk) { ?>
              <div class="col-lg-6 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green">
                  <div class="inner">
                    <h4><strong>Produk : <?php  echo $hitung_produk->jumlahproduk; ?></strong></h4>
                  </div>
                  <a  href="<?php echo base_url('Admin/produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div><!-- ./col -->
            <?php   } ?>
          </div><!-- /.row -->
        </section>
        <!-- Main content -->        
        <?php echo $this->session->flashdata('message');?>
        <section class="content">
          <div class="box box-primary">
            <div class="box-body box-profile">
              <?php echo form_open_multipart('Admin/add_produk');?>
              <div class="form-group">
                <select class="form-control select2" name="id_ktgr_produk" style="width: 100%;"required>
                  <option> Pilih Kategori Produk </option>
                  <?php foreach ($kategori_produk as $kategori_produk) { ?>
                    <option value="<?php echo $kategori_produk->id_ktgr_produk?>" >
                      <?php echo $kategori_produk->nm_ktgr_produk ?> 
                    </option>
                  <?php } ?>
                </select>
              </div>
              <div class="form-group">
                <input type="text" name="nama_produk"  id="nama_produk" class="form-control" required placeholder="Nama Produk">
                <input type="hidden" name="is_active"  id="is_active" class="form-control" required value="1" readonly>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="deskripsi_produk" placeholder="Deskripsi Produk" required></textarea>
              </div>
               <div class="form-group">
                <input type="text" name="link_produk"  id="link_produk" class="form-control" required placeholder="Link Produk">
              </div>
              <div class="form-group">
                <div class="row-md-10">
                  <label>Foto Produk</label>
                  <div class="custom-file form-control">
                    <input type="file" class="custom-file-input" id="brosur" name="brosur">
                  </div>                        
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
        <!-- general form elements disabled -->
        
        <div class="box">
         <div class="box box-primary">
          <div class="box-header with-border  bg-blue">
            <h3 class="box-title">Produk</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Foto</th>
                  <th>Kategori</th>
                  <th>Produk</th>
                  <th>Deskripsi</th>
                  <th>Link</th>
                  <th>Aktivasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php  $no = 1;
               foreach ($produk as $produk):?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td>
                    <?php if($produk->brosur == ' '){?>
                      <?php echo $produk->brosur?>
                    <?php } if($produk->brosur != ''){?>
                      <a href="javascript:void(0)" data-toggle="modal" data-target="#lihat<?php echo $produk->id_produk ?>"><img src="<?= base_url('assets/brosur/').$produk->brosur ?>" class="img-fluid" height="100px" width="100px"/>
                      </a>
                    <?php }?>
                  </td>
                  <td><?php echo $produk->nm_ktgr_produk; ?></td>
                  <td><?php echo $produk->nama_produk; ?></td>
                  <td><?php echo $produk->deskripsi_produk; ?></td>                  
                  <td><a href="<?php echo $produk->link_produk; ?>"><?php echo $produk->link_produk; ?></a></td>
                  <td>
                    <?php  
                    $is_active = $produk->is_active;
                    if ($is_active == 1) {
                      ?>
                      <a href="status_produk?$id_produk=<?php echo $produk->id_produk;?>&$is_active=<?php echo $produk->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                      <?php
                    }
                    else{
                      ?>
                      <a href="status_produk?$id_produk=<?php echo $produk->id_produk;?>&$is_active=<?php echo $produk->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                      <?php
                    }
                    ?>
                  </td>
                  <td><?php echo anchor('Admin/edit_produk/'.$produk->id_produk, '<div class="btn btn-circle btn-sm btn-primary"><i class="fas fa-edit"></i></div>') ?></a>

                    <a onclick="deleteConfirm('<?php echo base_url('Admin/delete_produk/'.$produk->id_produk) ?>')" href="#" class="btn btn-circle btn-sm btn-danger"><div><i class="fas fa-trash"></i></div></a>

                  </td>
                </tr>
                <!-- modal tampil gamabr -->
                <div class="modal fade" id="lihat<?php echo $produk->id_produk ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header bg-green">
                        <h4 class="modal-title text-white" id="exampleModalLabel">Detail Foto Produk</h4>
                        <button type="button" class="close bg-success" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="post" action="<?php echo base_url().'Admin/produk' ?>">
                          <div class="form-group">
                            <img src="<?= base_url('assets/brosur/').$produk->brosur ?>" class="img-fluid" />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- akhir moodel tampil gambar -->
              <?php endforeach; ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->

  <script>
    function deleteConfirm(url){
      $('#btn-delete').attr('href', url);
      $('#deleteModal').modal();
    }
  </script>
