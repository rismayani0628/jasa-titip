      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->        
        <?php echo $this->session->flashdata('message');?>
        <section class="content">
          <div class="box box-primary">
            <div class="box-body box-profile">
              <?php echo form_open_multipart('Admin/add_testimoni');?>
              <div class="form-group">
                <input type="text" name="nama_testi"  id="nama_testi" class="form-control" required placeholder="Nama tester">
                <input type="hidden" name="is_active"  id="is_active" class="form-control" required value="1" readonly>
              </div>
              <div class="form-group">
                <input type="text" name="pekerjaan"  id="nama_testi" class="form-control" required placeholder="Pekerjaan">
              </div>
              <div class="form-group">
                <textarea class="form-control" name="deskripsi_testi" placeholder="Deskripsi Testi" required></textarea>
              </div>
              <div class="form-group">
                <div class="row-md-10">
                  <label>Foto Testi</label>
                  <div class="custom-file form-control">
                    <input type="file" class="custom-file-input" id="foto_testi" name="foto_testi">
                  </div>                        
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
        <!-- general form elements disabled -->
        
        <div class="box">
         <div class="box box-primary">
          <div class="box-header with-border  bg-blue">
            <h3 class="box-title">Tetsimoni</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Foto</th>
                  <th>Nama</th>
                  <th>Pekerjaan</th>
                  <th>Deskripsi</th>
                  <th>Aktivasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
               <?php  $no = 1;
               foreach ($testimoni as $testimoni):?>
                <tr>
                  <td><?php echo $no++ ?></td>
                  <td>
                    <?php if($testimoni->foto_testi == ' '){?>
                      <?php echo $testimoni->foto_testi?>
                    <?php } if($testimoni->foto_testi != ''){?>
                      <a href="javascript:void(0)" data-toggle="modal" data-target="#lihat<?php echo $testimoni->id_testimoni ?>"><img src="<?= base_url('assets/img/foto_testi/').$testimoni->foto_testi ?>" class="img-fluid" height="100px" width="100px"/>
                      </a>
                    <?php }?>
                  </td>
                  <td><?php echo $testimoni->nama_testi; ?></td>
                  <td><?php echo $testimoni->pekerjaan; ?></td>
                  <td><?php echo $testimoni->deskripsi_testi; ?></td>
                   <td>
                    <?php  
                    $is_active = $testimoni->is_active;
                    if ($is_active == 1) {
                      ?>
                      <a href="status_testimoni?$id_testimoni=<?php echo $testimoni->id_testimoni;?>&$is_active=<?php echo $testimoni->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                      <?php
                    }
                    else{
                      ?>
                      <a href="status_testimoni?$id_testimoni=<?php echo $testimoni->id_testimoni;?>&$is_active=<?php echo $testimoni->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                      <?php
                    }
                    ?>
                  </td>
                  <td><?php echo anchor('Admin/edit_testimoni/'.$testimoni->id_testimoni, '<div class="btn btn-circle btn-sm btn-primary"><i class="fas fa-edit"></i></div>') ?></a>
                  </td>
                </tr>
                <!-- modal tampil gamabr -->
                <div class="modal fade" id="lihat<?php echo $testimoni->id_testimoni ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header bg-green">
                        <h4 class="modal-title text-white" id="exampleModalLabel">Foto</h4>
                        <button type="button" class="close bg-success" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="post" action="<?php echo base_url().'Admin/testi' ?>">
                          <div class="form-group">
                            <img src="<?= base_url('assets/img/foto_testi/').$testimoni->foto_testi ?>" class="img-fluid" />
                          </div>

                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- akhir moodel tampil gambar -->
              <?php endforeach; ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->

  <script>
    function deleteConfirm(url){
      $('#btn-delete').attr('href', url);
      $('#deleteModal').modal();
    }
  </script>
