<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Hak Akses
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('Admin') ?>"><i class="fa fa-desktop"></i> Home</a></li>
      <li class="active">Hak Akses</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">      
      <?php echo $this->session->flashdata('message');?>
      <div class="col-md-5">
        <div class="box box-primary">
          <div class="box-body box-profile">
            <form method="post" action="<?php echo base_url().'Admin/add_userrole' ?>">
              <div class="form-group">
                <label for="role">Hak Kases</label>
                <input type="text" name="role"  id="role" class="form-control" required placeholder="Hak Akses">
              </div>
              <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label>Team :</label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <input type="radio" name="team" value="Ya">
                    <label>Ya</label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">     
                    <input type="radio" name="team" value="Tidak">
                    <label>Tidak</label>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
      </div>
      <!-- Profile Image -->

      <div class="col-md-7">
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Form Hak Akses</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-condensed table-hover">
              <thead>
                <tr>
                  <th>id</th>
                  <th>Hak Akses</th>
                  <th>Team</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                foreach ($data as $data):?>
                  <tr>
                    <td><?php echo $data->id?></td>
                    <td><?php echo $data->role?></td>
                    <td><?php if ($data->team == 'Ya' ) {?>
                      <a href="#" class="btn btn-circle btn-sm btn-success"><div><i class="fa fas fa-check"></i></div></a>
                    <?php } if ($data->team == 'Tidak'){ ?>
                      <a href="#" class="btn btn-circle btn-sm btn-danger"><div><i class="fa fas fa-close"></i></div></a>                      
                    <?php } ?>
                  </td>
                  <td><a href="javascript:void(0)" data-toggle="modal" data-target="#edituserrole<?php echo $data->id ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                  </td>
                </tr>
              </tbody>
              <!-- Modal edit jenjang -->
              <div class="modal fade" id="edituserrole<?php echo $data->id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header bg-primary">
                      <h4 class="modal-title" id="exampleModalLabel">Form Edit Hak Akses</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="post" action="<?php echo base_url().'Admin/edit_userrole/'.$data->id ?>">
                        <div class="form-group">
                          <label>Hak Akses</label>
                          <input type="text" name="role" class="form-control" value="<?= $data->role; ?>">
                        </div>
                        <div class="row">
                          <div class="col-md-2">
                            <div class="form-group">
                              <label>Team :</label>
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <?php if($data->team == 'Ya'){?>
                                <input type="radio" name="team" value="<?php echo $data->team?>" checked>
                                <label>Ya</label>
                              <?php } else{?>
                                <input type="radio" name="team" value="Ya">
                                <label>Ya</label>
                              <?php }?>
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <?php  if($data->team== 'Tidak'){?>
                                <input type="radio" name="team" value="<?php echo $data->team?>" checked>
                                <label>Tidak</label> 
                              <?php } else{?>               
                                <input type="radio" name="team" value="Tidak">
                                <label>Tidak</label>
                              <?php }?>
                            </div>
                          </div>
                        </div>
                        <button type="submit" class="btn btn-success btn-icon-split btn-sm" value="save">
                          <span class="icon text-white-50">
                            <i class="fas fa-check"></i>
                          </span>
                          <span class="text">Edit</span> 
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <!-- Akhir modal edit jenjang -->
            <?php endforeach; ?>
          </table>
        </div><!-- /.box-body -->
      </div><!-- /.box -->
    </div><!-- /.col -->
  </div>
</section>
</div>
