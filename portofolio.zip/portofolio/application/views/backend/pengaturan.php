<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Pengaturan Header
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">
    <?php echo $this->session->flashdata('message');?>
    <div class="box box-primary">
      <div class="box-header bg-blue">
        <h3 class="box-title text-light">Tambah data</h3>
      </div>
      <div class="box-body box-profile">
        <form method="post" action="<?php echo base_url().'Admin/add_pengaturan' ?>">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="about"></label>
                <textarea class="form-control" name="about" placeholder="Judul about" required></textarea>
                <input type="hidden" name="is_active" class="form-control" value="1" readonly>
              </div>
              <div class="form-group">
                <label for="service"></label>
                <textarea class="form-control" name="service" placeholder="Judul service" required></textarea>
              </div>
              <div class="form-group">
                <label for="product"></label>
                <textarea class="form-control" name="product" placeholder="Judul product" required></textarea>
              </div>              
              <div class="form-group">
                <label for="patner"></label>
                <textarea class="form-control" name="patner" placeholder="Judul patner" required></textarea>
              </div>  
            </div>

            <div class="col-md-6">            
              <div class="form-group">
                <label for="testimoni"></label>
                <textarea class="form-control" name="testimoni" placeholder="Judul testimoni" required></textarea>
              </div>
              <div class="form-group">
                <label for="team"></label>
                <textarea class="form-control" name="team" placeholder="Judul team" required></textarea>
              </div>              
              <div class="form-group">
                <label for="contact"></label>
                <textarea class="form-control" name="contact" placeholder="Judul contact" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </div>
          </div>
        </form>          
      </div><!-- /.box-body -->
    </div><!-- /.box -->   

    <!-- Profile Image -->

    <div class="box box-primary">
      <div class="box-header bg-blue">
        <h3 class="box-title">Konfigurasi Header</h3>
      </div><!-- /.box-header -->
      <div class="box-body">
        <table id="example1" class="table table-bordered table-condensed table-hover">
          <thead>
            <tr>
              <th>No</th>
              <th>About</th>
              <th>Service</th>
              <th>Product</th>
              <th>Patner</th>
              <th>Testimoni</th>
              <th>Team</th>
              <th>Contact</th>
              <th>Aktivasi</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $no = 1;
            foreach ($data as $data):?>
              <tr>
                <td><?php echo $no++?></td>
                <td><?php echo $data->about?></td>
                <td><?php echo $data->service?></td>
                <td><?php echo $data->product?></td>
                <td><?php echo $data->patner?></td>
                <td><?php echo $data->testimoni?></td>
                <td><?php echo $data->team?></td>
                <td><?php echo $data->contact?></td>
                <td>
                  <?php  
                  $is_active = $data->is_active;
                  if ($is_active == 1) {
                    ?>
                    <a href="status_pengaturan?$id_konfigurasi=<?php echo $data->id_konfigurasi;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                    <?php
                  }
                  else{
                    ?>
                    <a href="status_pengaturan?$id_konfigurasi=<?php echo $data->id_konfigurasi;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                    <?php
                  }
                  ?>
                </td>
                <td><a href="javascript:void(0)" data-toggle="modal" data-target="#editkonfigurasi<?php echo $data->id_konfigurasi ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                </td>
              </tr>
            </tbody>
            <!-- Modal edit jenjang -->
            <div class="modal fade" id="editkonfigurasi<?php echo $data->id_konfigurasi ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header bg-primary">
                    <h4 class="modal-title" id="exampleModalLabel">Form Edit</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form method="post" action="<?php echo base_url().'Admin/edit_pengaturan/'.$data->id_konfigurasi ?>">
                      <div class="form-group">
                        <label>About</label>
                         <textarea class="form-control" name="about" placeholder="Deskripsi Produk" required><?= $data->about; ?></textarea>
                        <input type="hidden" name="id_konfigurasi" class="form-control" value="<?= $data->id_konfigurasi; ?>">
                        <input type="hidden" name="is_active" class="form-control" value="<?= $data->is_active; ?>">
                      </div>
                      <div class="form-group">
                        <label>service</label>
                         <textarea class="form-control" name="service" placeholder="Deskripsi Produk" required><?= $data->service; ?></textarea>
                      </div>
                      <div class="form-group">
                        <label>product</label>
                        <textarea class="form-control" name="product" placeholder="Deskripsi Produk" required><?= $data->product; ?></textarea>
                      </div>
                      <div class="form-group">
                        <label>patner</label>
                         <textarea class="form-control" name="patner" placeholder="Deskripsi Produk" required><?= $data->patner; ?></textarea>
                      </div>
                      <div class="form-group">
                        <label>testimoni</label>
                        <textarea class="form-control" name="testimoni" placeholder="Deskripsi Produk" required><?= $data->testimoni; ?></textarea>
                      </div>
                      <div class="form-group">
                        <label>team</label>
                         <textarea class="form-control" name="team" placeholder="Deskripsi Produk" required><?= $data->team; ?></textarea>
                      </div>
                      <div class="form-group">
                        <label>contact</label>
                        <textarea class="form-control" name="contact" placeholder="Deskripsi Produk" required><?= $data->contact; ?></textarea>
                      </div>
                      <button type="submit" class="btn btn-success btn-icon-split btn-sm" value="save">
                        <span class="icon text-white-50">
                          <i class="fas fa-check"></i>
                        </span>
                        <span class="text">Edit</span> 
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <!-- Akhir modal edit jenjang -->
          <?php endforeach; ?>
        </table>
      </div><!-- /.box-body -->
    </div>
  </section>
</div>
