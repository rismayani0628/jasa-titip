<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      User Profile
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">Edit profile</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-md-4">
        <div class="box box-primary">
          <?php echo $this->session->flashdata('message');?>
          <div class="box-body box-profile">
            <form method="post" action="<?php echo base_url().'Admin/changepassword' ?>">
              <div class="form-group">
                <label for="current_password">Current Password (Password Sebelumnya)</label>
                <input type="password" name="current_password"  id="current_password" class="form-control">
                <?= form_error('current_password', ' <small class="text-danger" pl-3>', '</small>'); ?>
              </div>
              <div class="form-group">
                <label for="new_password1">New Password</label>
                <input type="password" name="new_password1"  id="new_password1" class="form-control">
                <?= form_error('new_password1', ' <small class="text-danger" pl-3>', '</small>'); ?>
              </div>
              <div class="form-group">
                <label for="new_password2">Repeat Password</label>
                <input type="password" name="new_password2"  id="new_password2" class="form-control">
                <?= form_error('new_password2', ' <small class="text-danger" pl-3>', '</small>'); ?>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Ubah Password</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
      </div>
      <!-- Profile Image -->
      <?php echo form_open_multipart('Admin/edit_akun');?>
      <div class="col-md-8">
        <div class="box box-primary">
          <div class="box-body box-profile">
            <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url('assets/img/'). $user['foto'];?>" alt="User profile picture">
            <h3 class="profile-username text-center"><?php echo $user['nama']; ?></h3>
            <div class="form-group center">
             <div class="card-body">
              <div class="form-group row">
                <label for="username" class="col-sm-2 col-form-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="username" name="username" value="<?php echo $user ['username']; ?>" readonly>
                </div>
              </div>
              <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $user ['nama']; ?>">
                  <?= form_error('nama', ' <small class="text-danger" pl-3>', '</small>'); ?>
                </div>
              </div>
              <div class="form-group row">
                <label for="jk" class="col-sm-2 col-form-label">TTL</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="ttl" name="ttl" value="<?php echo $user ['ttl']; ?>">
                  <?= form_error('ttl', ' <small class="text-danger" pl-3>', '</small>'); ?>
                </div>
              </div>
              <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label>JK </label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <?php if($user['jk'] == 'P'){?>
                      <input type="radio" name="jk" value="<?php echo $user['jk']?>" checked>
                      <label>Perempuan</label>
                    <?php } else{?>
                      <input type="radio" name="jk" value="P">
                      <label>Perempuan</label>
                    <?php }?>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <?php  if($user['jk']== 'L'){?>
                      <input type="radio" name="jk" value="<?php echo $user['jk']?>" checked>
                      <label>Laki-Laki</label> 
                    <?php } else{?>               
                      <input type="radio" name="jk" value="L">
                      <label>Laki-Laki</label>
                    <?php }?>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $user ['alamat']; ?>">
                  <?= form_error('alamat', ' <small class="text-danger" pl-3>', '</small>'); ?>
                </div>
              </div>
              <div class="form-group row">
                <label for="hp" class="col-sm-2 col-form-label">Nomor HP</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="hp" name="hp" value="<?php echo $user ['hp']; ?>">
                  <?= form_error('hp', ' <small class="text-danger" pl-3>', '</small>'); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-sm-2">Foto</label>
                <div class="col-sm-10">
                  <div class="row">
                    <div class="col-sm-3">
                      <img src="<?= base_url('assets/img/') . $user['foto'];?>" class="img-thumbnail">
                    </div>
                    <div class="col-sm-9">
                      <div class="custom-file form-group">
                        <input type="file" class="custom-file-input form-control" id="foto" name="foto">
                        <label class="custom-file-label" for="foto" name="foto">Choose file</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- button -->
              <a href="<?php echo base_url("Admin/profil") ?>" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                    
              </a>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm" value="save">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span> 
              </button>
              <!-- akhir button -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>   
</section>
</div>