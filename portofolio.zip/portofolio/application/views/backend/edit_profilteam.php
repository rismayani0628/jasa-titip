<div class="content-wrapper">
	<?php echo $this->session->flashdata('message');?>
	<section class="content">
		<div class="box box-primary">
			<div class="box-header bg-blue">
				<h3 class="box-title"> Ubah Profil Team</i></h3>
			</div><!-- /.box-header -->
			<div class="box-body box-profile">
				<?php foreach($profil_team as $data){ ?>
					<?php echo form_open_multipart('Admin/update_profiltim');?>
					<div class="form-group">
						<input type="hidden" class="form-control" placeholder="username" name="username" value="<?= set_value('username');?>">
						<input type="hidden" class="form-control" name="id_user" value="<?php echo $data->id_user ?>"> 
						<input type="hidden" class="form-control" name="password" value="<?php echo $data->password ?>">
						<input type="hidden" class="form-control" name="is_active" value="<?php echo $data->is_active ?>">
						<input type="hidden" class="form-control" name="foto" value="<?php echo $data->foto ?>">
						<input type="hidden" class="form-control" name="date_created" value="<?php echo $data->date_created ?>">      

						<input type="text" class="form-control" name="nama" value="<?php echo $data->nama ?>">  
					</div>

					<div class="form-group">
						<input type="text" class="form-control" name="ttl" value="<?php echo $data->ttl ?>">
					</div>

					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label>Jenis Kelamin :</label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<?php if($data->jk == 'P'){?>
									<input type="radio" name="jk" value="<?php echo $data->jk?>" checked>
									<label>Perempuan</label>
								<?php } else{?>
									<input type="radio" name="jk" value="P">
									<label>Perempuan</label>
								<?php }?>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<?php  if($data->jk== 'L'){?>
									<input type="radio" name="jk" value="<?php echo $data->jk?>" checked>
									<label>Laki-Laki</label> 
								<?php } else{?>               
									<input type="radio" name="jk" value="L">
									<label>Laki-Laki</label>
								<?php }?>
							</div>
						</div>
					</div>

					<div class="form-group">
						<input type="text" class="form-control" name="alamat" value="<?php echo $data->alamat ?>">  
					</div>

					<div class="form-group">
						<input type="number" class="form-control" name="hp" value="<?php echo $data->hp ?>">  
					</div>

					<div class="form-group">
						<input type="text" class="form-control" name="link_twiter" value="<?php echo $data->link_twiter ?>" placeholder="Link Twiter">  
					</div>

					<div class="form-group">
						<input type="text" class="form-control" name="link_facebook" value="<?php echo $data->link_facebook ?>" placeholder="Link Facebook">  
					</div>

					<div class="form-group">
						<input type="text" class="form-control" name="link_instagram" value="<?php echo $data->link_instagram ?>" placeholder="Link Instagram">  
					</div>

					<div class="form-group">
						<label for="role_id">Pilih Status Keanggotaan*</label>
						<div class="role_id">
							<select name="role_id" class="form-control select2">
								<?php foreach ($user_role as $r)
								{
									if($r->id == $data->role_id){
										echo '<option selected value="'.$r->id.'">'.$r->role.' </option>';}
										else{
											echo '<option value="'.$r->id.'">'.$r->role.'</option>';           
										}
									}
									?>
								</select>
							</div>
						</div>

						<div class="form-group row">
							<div class="col-sm-12">
								<div class="row">
									<div class="col-sm-3">
										<img src="<?= base_url('assets/img/') . $data->foto?>" class="img-thumbnail">
									</div>
									<div class="col-sm-9">
										<div class="custom-file">
											<input type="file" class="custom-file-input" name="foto">
											<label class="custom-file-label" for="foto">Pilih Foto</label>
										</div>
									</div>
								</div>
							</div>
						</div>

						<button type="submit" class="btn btn-primary btn-icon-split btn-sm">
							<span class="icon text-white-50">
								<i class="fas fa-check"></i>
							</span>
							<span class="text">Simpan</span>                       
						</button>
						<button type="reset" class="btn btn-danger btn-icon-split btn-sm">
							<span class="icon text-white-50">
								<i class="fas fa-times"></i>
							</span>
							<span class="text">Batal</span>                       
						</button>
					</form> 					
				<?php } ?>          
			</div><!-- /.box-body -->
		</div><!-- /.box -->   
		<!-- general form elements disabled -->
	</section>
</div>