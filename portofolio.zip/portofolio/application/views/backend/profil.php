<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      User Profile
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('Admin') ?>"><i class="fa  fa-tachometer-alt"></i> Dashboard</a></li>
      <li class="active">User profile</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <div class="row">
      <div class="col-md-12">
        <!-- Profile Image -->       
          <?php echo $this->session->flashdata('message');?>
        <?php  foreach ($data as $d):?>
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url('assets/img/'). $user['foto'];?>" alt="User profile picture">
              <h3 class="profile-username text-center"><?php echo $user['nama']; ?></h3>
              <p class="text-muted text-center">Level : <?php echo $d->role; ?></p>
              <div class="form-group center">
                <table class="table table-user-information">
                  <tbody>
                    <tr>
                      <td>Nama</td>
                      <td>: <?php echo $d->nama?></td>
                    </tr>
                    <tr>
                      <td>Tempat Tanggal Lahir</td>
                      <td>: <?php echo $d->ttl?></td>
                    </tr>
                    <tr>
                      <td>Jenis Kelamin</td>
                      <td>: <?php if($d->jk == 'P' ){?>
                        Perempuan                      
                      <?php } if($d->jk == 'L'){?> 
                        Laki-Laki
                      <?php }?>
                    </td>
                  </tr>
                  <tr>
                    <td>Alamat</td>
                    <td>: <?php echo $d->alamat?></td>
                  </tr>
                  <tr>
                    <td>HP</td>
                    <td>: <?php echo $d->hp?></td>
                  </tr>
                  <tr>
                    <td>Bergabung Sejak</td>
                    <td>: <?php echo date ('d F Y', $user['date_created']); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <a href="<?php echo base_url('Admin/edit_akun/')?>" class="btn btn-primary btn-block"><b>Edit Profil</b></a>
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
      <?php endforeach; ?>
    </div><!-- /.col -->
  </div><!-- /.row -->

</section><!-- /.content -->
</div><!-- /.content-wrapper -->