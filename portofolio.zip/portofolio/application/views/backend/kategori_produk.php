      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <section class="content-header">
         <div class="row">
          <?php foreach ($hitung_ktgrproduk as $hitung_ktgrproduk) { ?>
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                  <h4><strong>Kategori Produk : <?php  echo $hitung_ktgrproduk->jumlahktgrproduk; ?></strong></h4>
                </div>
                <a href="<?php echo base_url('Admin/kategori_produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          <?php   } ?>

          <!--   produk -->
          <?php foreach ($hitung_produk as $hitung_produk) { ?>
            <div class="col-lg-6 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h4><strong>Produk : <?php  echo $hitung_produk->jumlahproduk; ?></strong></h4>
                </div>
                <a  href="<?php echo base_url('Admin/produk') ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          <?php   } ?>
        </div><!-- /.row -->
      </section>
      <section class="content">          
        <?php echo $this->session->flashdata('message');?>
        <div class="row">
          <!-- right column -->
          <div class="col-md-6">
            <!-- Horizontal Form -->
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Tambah Kategori Produk </h3>
              </div><!-- /.box-header -->
              <!-- form start -->
              <form action="<?php echo base_url().'Admin/add_ktgrproduk' ?>" method="post" class="form-horizontal" >
                <div class="box-body">
                  <label class="col-sm-4 control-label">Kategori Produk</label>
                  <div class="col-sm-8 form-group">
                    <input type="text" name="nm_ktgr_produk"  id="nm_ktgr_produk" class="form-control">
                  </div>
                </div><!-- /.box-body -->
                <div class="box-footer">
                  <button type="submit" class="btn btn-primary btn-icon-split btn-sm pull-right">
                    <span class="icon text-white-50">
                      <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Simpan</span>                       
                  </button>
                </div><!-- /.box-footer -->
              </form>
            </div><!-- /.box -->
          </div>
          <!-- general form elements disabled -->
          <div class="col-md-6">
            <div class="box">
             <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Kategori Produk</h3>
              </div><!-- /.box-header -->
              <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Kategori Produk</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                   <?php  $no = 1;
                   foreach ($kategori_produk as $kategori_produk):?>
                    <tr>
                      <td><?php echo $no++ ?></td>
                      <td><?php echo $kategori_produk->nm_ktgr_produk; ?></td>
                      <td><a href="javascript:void(0)" data-toggle="modal" data-target="#editktgrproduk<?php echo $kategori_produk->id_ktgr_produk ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                      </td>
                    </tr>
                    <!-- Modal edit jenjang -->
                    <div class="modal fade" id="editktgrproduk<?php echo $kategori_produk->id_ktgr_produk ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header bg-primary">
                            <h4 class="modal-title" id="exampleModalLabel">Form Edit Kategori Produk</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form method="post" action="<?php echo base_url().'Admin/edit_ktgr_produk/'.$kategori_produk->id_ktgr_produk ?>">
                              <div class="form-group">
                                <label>Kategori Produk</label>
                                <input type="text" name="nm_ktgr_produk" class="form-control" value="<?= $kategori_produk->nm_ktgr_produk; ?>">
                              </div>
                              <button type="submit" class="btn btn-primary btn-icon-split btn-sm" value="save">
                                <span class="icon text-white-50">
                                  <i class="fas fa-check"></i>
                                </span>
                                <span class="text">Edit</span> 
                              </button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- Akhir modal edit jenjang -->
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div><!-- /.box-body -->
          </div><!-- /.box -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </section><!-- /.content -->
  </div><!-- /.content-wrapper -->
