<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Service / Layanan
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url('Admin') ?>"><i class="fa fa-desktop"></i> Home</a></li>
      <li class="active">Service</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">      
      <?php echo $this->session->flashdata('message');?>
      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header bg-blue">
            <h3 class="box-title text-light">Tambah data layanan</h3>
          </div>
          <div class="box-body box-profile">
            <form method="post" action="<?php echo base_url().'Admin/add_service' ?>">
              <div class="form-group">
                <label for="nama_service"></label>
                <input type="hidden" name="is_active" class="form-control" value="1" required>
                <input type="text" name="nama_service" class="form-control" placeholder="Nama Layanan" required>
              </div>
              <div class="form-group">
                <label for="icon"></label>
                <input type="text" name="icon" class="form-control" placeholder="Tuliskan icon layanan" required>
              </div>
              <div class="form-group">
                <label for="keterangan"></label>
                <textarea class="form-control" name="keterangan" placeholder="Keterangan layananan" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-check"></i>
                </span>
                <span class="text">Simpan</span>                       
              </button>
              <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                <span class="icon text-white-50">
                  <i class="fas fa-times"></i>
                </span>
                <span class="text">Batal</span>                       
              </button>
            </form>          
          </div><!-- /.box-body -->
        </div><!-- /.box -->   
      </div>
      <!-- Profile Image -->

      <div class="col-md-6">
        <div class="box box-primary">
          <div class="box-header bg-blue">
            <h3 class="box-title">Form Service</h3>
          </div><!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-condensed table-hover">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Service</th>
                  <th>Icon</th>
                  <th>Keterangan</th>
                  <th>Aktivasi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no = 1;
                foreach ($data as $data):?>
                  <tr>
                    <td><?php echo $no++?></td>
                    <td><?php echo $data->nama_service?></td>
                    <td><?php echo $data->icon?></td>
                    <td><?php echo $data->keterangan?></td>
                    <td>
                      <?php  
                      $is_active = $data->is_active;
                      if ($is_active == 1) {
                        ?>
                        <a href="status_service?$id_service=<?php echo $data->id_service;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                        <?php
                      }
                      else{
                        ?>
                        <a href="status_service?$id_service=<?php echo $data->id_service;?>&$is_active=<?php echo $data->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                        <?php
                      }
                      ?>
                    </td>
                    <td><a href="javascript:void(0)" data-toggle="modal" data-target="#editservice<?php echo $data->id_service ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                    </td>
                  </tr>
                </tbody>
                <!-- Modal edit jenjang -->
                <div class="modal fade" id="editservice<?php echo $data->id_service ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header bg-primary">
                        <h4 class="modal-title" id="exampleModalLabel">Form Edit Service/Layanan</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="post" action="<?php echo base_url().'Admin/edit_service/'.$data->id_service ?>">
                          <div class="form-group">
                            <label>Service</label>
                            <input type="text" name="nama_service" class="form-control" value="<?= $data->nama_service; ?>">
                          </div>
                          <div class="form-group">
                            <label>Icon</label>
                            <input type="text" name="icon" class="form-control" value="<?= $data->icon; ?>">
                            <input type="hidden" name="is_active" class="form-control" value="<?= $data->is_active; ?>">
                          </div>
                          <div class="form-group">
                            <label>Keterangan</label>
                             <textarea class="form-control" name="keterangan" placeholder="Deskripsi Produk" required><?= $data->keterangan; ?></textarea>
                          </div>
                          <button type="submit" class="btn btn-success btn-icon-split btn-sm" value="save">
                            <span class="icon text-white-50">
                              <i class="fas fa-check"></i>
                            </span>
                            <span class="text">Edit</span> 
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Akhir modal edit jenjang -->
              <?php endforeach; ?>
            </table>
          </div><!-- /.box-body -->
        </div><!-- /.box -->
      </div><!-- /.col -->
    </div>
  </section>
</div>
