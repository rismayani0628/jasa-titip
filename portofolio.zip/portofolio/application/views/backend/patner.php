      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->        
        <?php echo $this->session->flashdata('message');?>
        <section class="content">
          <div class="row">
            <div class="col-md-6">
              <div class="box box-primary">
                <div class="box-body box-profile">
                  <?php echo form_open_multipart('Admin/add_patner');?>

                  <div class="form-group">
                    <input type="text" name="nm_instansi"  id="nm_instansi" class="form-control" required placeholder="Nama Patner">
                    <input type="hidden" name="is_active"  id="is_active" class="form-control" required value="1" readonly>
                  </div>
                  <div class="form-group">
                    <input type="text" name="link_patner"  id="link_patner" class="form-control" required placeholder="Link Patner">
                  </div>

                  <div class="form-group">
                    <div class="row-md-10">
                      <label>Foto Patner</label>
                      <div class="custom-file form-control">
                        <input type="file" class="custom-file-input" id="gambar_patner" name="gambar_patner">
                      </div>                        
                    </div>
                  </div>
                  
                  <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                      <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Simpan</span>                       
                  </button>
                  <button type="reset" class="btn btn-danger btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                      <i class="fas fa-times"></i>
                    </span>
                    <span class="text">Batal</span>                       
                  </button>
                </form>          
              </div><!-- /.box-body -->
            </div><!-- /.box -->   
          </div>
          <!-- general form elements disabled -->
          <div class="col-md-6">
           <div class="box box-primary">
            <div class="box-header with-border  bg-blue">
              <h3 class="box-title">Patner</h3>
            </div><!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Nama Patner</th>
                    <th>Link</th>
                    <th>Aktivasi</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                 <?php  $no = 1;
                 foreach ($patner as $p):?>
                  <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $p->nm_instansi ?></td>
                    <td><a href="<?php echo $p->link_patner ?>"><?php echo $p->link_patner ?></a></td>
                    <td>
                      <?php if($p->gambar_patner == ' '){?>
                        <?php echo $p->gambar_patner?>
                      <?php } if($p->gambar_patner != ''){?>
                        <img src="<?= base_url('assets/img/patner/').$p->gambar_patner ?>" class="img-fluid" height="100px" width="100px"/>
                      <?php }?>
                    </td>                      
                    <td>
                      <?php  
                      $is_active = $p->is_active;
                      if ($is_active == 1) {
                        ?>
                        <a href="status_patner?$id_patner=<?php echo $p->id_patner;?>&$is_active=<?php echo $p->is_active?>" class ="btn btn-sm btn-success">Aktif</a>
                        <?php
                      }
                      else{
                        ?>
                        <a href="status_patner?$id_patner=<?php echo $p->id_patner;?>&$is_active=<?php echo $p->is_active?>" class ="btn btn-sm btn-danger">Non Aktif</a>
                        <?php
                      }
                      ?>
                    </td>
                    <td>
                      <a href="javascript:void(0)" data-toggle="modal" data-target="#editpatner<?php echo $p->id_patner ?>"  class="btn btn-circle btn-sm btn-primary"><div><i class="fas fa-edit"></i></div></a>
                    </td>
                  </tr>
                  <!-- Modal edit patner -->
                  <div class="modal fade" id="editpatner<?php echo $p->id_patner ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header bg-primary">
                          <h4 class="modal-title" id="exampleModalLabel">Form Edit patner</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <?php echo form_open_multipart('Admin/update_patner/'.$p->id_patner);?>
                          <div class="form-group">
                            <input type="text" class="form-control" name="nm_instansi" value="<?php echo $p->nm_instansi ?>">
                          </div>
                          <div class="form-group">
                            <input type="text" class="form-control" name="link_patner" value="<?php echo $p->link_patner ?>">
                          </div>
                          <div class="form-group row">
                            <div class="col-sm-12">
                              <div class="row">
                                <div class="col-sm-3">
                                  <img src="<?= base_url('assets/img/patner/') .$p->gambar_patner?>" class="img-thumbnail"> 
                                  <input type="hidden" name="id_patner" class="form-control" value="<?= $p->id_patner; ?>">
                                </div>
                                <div class="col-sm-9">
                                  <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="gambar_patner">
                                    <label class="custom-file-label" for="gambar_patner">Choose file</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <button type="submit" class="btn btn-success btn-icon-split btn-sm" value="save">
                            <span class="icon text-white-50">
                              <i class="fas fa-check"></i>
                            </span>
                            <span class="text">Edit</span> 
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Akhir modal edit patner -->
              <?php endforeach; ?>
            </tbody>
          </table>
        </div><!-- /.box-body -->
      </div>
    </div>
  </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<script>
  function deleteConfirm(url){
    $('#btn-delete').attr('href', url);
    $('#deleteModal').modal();
  }
</script>
