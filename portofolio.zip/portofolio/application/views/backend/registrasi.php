<div class="content-wrapper">
	<?php echo $this->session->flashdata('message');?>
	<section class="content">
		<div class="box box-primary">
			<div class="box-header bg-blue">
				<h3 class="box-title"> Registrasi Team</i></h3>
			</div><!-- /.box-header -->
			<div class="box-body box-profile">
				<form class="registrasi" method="post" action="<?= base_url('Auth/registrasi'); ?>">
					<?= form_error('username', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="username" class="form-control" placeholder="username" name="username" value="<?= set_value('username');?>">
					</div>

					<?= form_error('nama', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="nama" class="form-control" placeholder="Nama" name="nama" value="<?= set_value('nama');?>">
					</div>

					<?= form_error('ttl', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="ttl" class="form-control" placeholder="Tempat Tanggal Lahir" name="ttl" value="<?= set_value('ttl');?>">
					</div>

					<?= form_error('jk', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label>JK :</label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<input type="radio" name="jk" value="P">
								<label>Perempuan</label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">     
								<input type="radio" name="jk" value="L">
								<label>Laki-Laki</label>
							</div>
						</div>
					</div>

					<?= form_error('alamat', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Alamat Siswa" name="alamat" value="<?= set_value('alamat');?>">
					</div>

					<?= form_error('hp', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="number" class="form-control" placeholder="HP Siswa" name="hp" value="<?= set_value('hp');?>">
					</div>

					<?= form_error('link_twiter', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Link Twiter" name="link_twiter" value="<?= set_value('link_twiter');?>">
					</div>

					<?= form_error('link_facebook', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Link Facebook" name="link_facebook" value="<?= set_value('link_facebook');?>">
					</div>

					<?= form_error('link_instagram', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Link Instagram" name="link_instagram" value="<?= set_value('link_instagram');?>">
					</div>

					<div class="form-group">
						<select class="form-control select2" name="role_id" style="width: 100%;"required>
							<option> Pilih Status Kanggotaan </option>
							<?php foreach ($user_role as $user_role) { ?>
								<option value="<?php echo $user_role->id?>" >
									<?php echo $user_role->role ?> 
								</option>
							<?php } ?>
						</select>
					</div>

					<?= form_error('password1', '<small class="text-danger mb-3">', '</small>') ?>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<input type="password" class="form-control" placeholder="Password" id="password1" name="password1">
							</div>
						</div>

						<!-- /.col -->
						<div class="col-md-6">
							<div class="form-group">
								<input type="password" class="form-control" placeholder="Ulangi Pass" name="password2" id="password2">
							</div>
						</div>
						<!-- /.col -->
					</div>
					
					<button type="submit" class="btn btn-primary btn-icon-split btn-sm">
						<span class="icon text-white-50">
							<i class="fas fa-check"></i>
						</span>
						<span class="text">Simpan</span>                       
					</button>
					<button type="reset" class="btn btn-danger btn-icon-split btn-sm">
						<span class="icon text-white-50">
							<i class="fas fa-times"></i>
						</span>
						<span class="text">Batal</span>                       
					</button>
				</form>          
			</div><!-- /.box-body -->
		</div><!-- /.box -->   
		<!-- general form elements disabled -->
	</section>
</div>