<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dagang Kita</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url() ?>assets/img/favicon.png" rel="icon">
  <link href="<?php echo base_url() ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medicio - v2.0.0
  * Template URL: https://bootstrapmade.com/medicio-free-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex align-items-center justify-content-between">
     <?php echo $this->session->flashdata('message');?>
   </div>
 </div>


 <!-- ======= Header ======= -->
 <header id="header" class="fixed-top">
  <div class="container d-flex align-items-center">

    <a href="<?php echo base_url('Home') ?>" class="logo mr-auto"><img src="<?php echo base_url() ?>assets/img/logo1.jpg" alt=""></a>
    <!-- Uncomment below if you prefer to use an image logo -->
    <!-- <h1 class="logo mr-auto"><a href="index.html">Medicio</a></h1> -->

    <nav class="nav-menu d-none d-lg-block">
      <ul>
        <li class="active"><a href="#hero">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#gallery">Product</a></li>
        <li><a href="#clients">Patner</a></li>
        <li><a href="#testimonials">Testimoni</a></li>
        <li><a href="#doctors">Team</a></li>          
        <li><a href="#contact">Contact</a></li>
        <?php if (!$this->session->userdata('username')){?>
          <li><a href="<?php echo base_url('Auth') ?>">Login</a></li>
        <?php } if($this->session->userdata('role_id') == 1 ){?>
          <li><a href="<?php echo base_url('Auth/logout') ?>">Logout</a></li>
        <?php }?>
        <!-- untuk menampilkan gambar dan nama yang login -->
        <?php if (!$this->session->userdata('username')){?>
        <?php } if($this->session->userdata('role_id') == 1 ){?>
          <li><a href="<?php echo base_url('Admin') ?>">
            <img class="img-profile rounded-circle" src="<?php echo base_url('assets/img/'). $user['foto'];?>" height="30px"> 
          </a></li>
        <?php } if($this->session->userdata('role_id') == 2 ){?>
          <li><a href="<?php echo base_url('Home') ?>">
            <img class="img-profile rounded-circle" src="<?php echo base_url('assets/img/'). $user['foto'];?>" height="30px"> 
          </a> </li>
        <?php }?>
      </ul>
    </nav><!-- .nav-menu -->

    <!--  <a href="#appointment" class="appointment-btn scrollto"><span class="d-none d-md-inline">Make an</span> Appointment</a> -->

  </div>
</header><!-- End Header -->

<!-- ======= Slider Section ======= -->
<section id="hero">
  <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

    <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    <div class="carousel-inner" role="listbox">
      <!-- Slide 1 -->
      <?php foreach ($slider1 as $slider1):?>
        <div class="carousel-item active" style="background-image: url(<?php echo base_url ('assets/slider/'). $slider1->gambar;?>)">
          <section>
            <a href="#gallery" class="btn-get-started scrollto">Galery Product</a>
          </section>
        </div>
      <?php endforeach; ?>
      <!-- Slide 2 -->
      <?php foreach ($slider2 as $slider2):?>
        <div class="carousel-item" style="background-image: url(<?php echo base_url ('assets/slider/'). $slider2->gambar;?>)">
          <section>
            <a href="#gallery" class="btn-get-started scrollto">Galery Product</a>
          </section>
        </div>
      <?php endforeach; ?>
      <!-- Slide 3 -->
      <?php foreach ($slider3 as $slider3):?>
        <div class="carousel-item" style="background-image: url(<?php echo base_url ('assets/slider/'). $slider3->gambar;?>)">
          <section>
            <a href="#gallery" class="btn-get-started scrollto">Galery Product</a>
          </section>
        </div>
      <?php endforeach; ?>
    </div>
    <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</section><!-- End Hero -->

<main id="main">

  <!-- ======= About Us Section ======= -->
  <section id="about" class="about">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2>About</h2>          
        <?php foreach ($konfigurasi as $konfig_a):?>
          <p class="textarea"><?php echo $konfig_a->about ?></p>          
        <?php endforeach; ?>
      </div>

      <div class="row">
        <?php foreach ($about as $a):?>
          <div class="col-lg-6" data-aos="fade-right">
            <img src="<?= base_url('assets/img/').$a->gambar_about ?>" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3><?php echo $a->judul ?></h3>
            <p class="textarea" align="justify">
              <?php echo $a->isi ?>
            </p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section><!-- End About Us Section -->

  <!-- ======= Services Section ======= -->
  <section id="services" class="services services">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <h2>Services</h2>
        <?php foreach ($konfigurasi as $konfig_s):?>
          <p class="textarea"><?php echo $konfig_s->service ?></p>          
        <?php endforeach; ?>
      </div>

      <div class="row">
        <?php foreach ($service as $service):?>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon"><i class="<?php echo $service->icon?>"></i></div>
            <h4 class="title"><a href=""><?php echo $service->nama_service?></a></h4>
            <p class="description"><?php echo $service->keterangan?></p>
          </div>
        <?php endforeach; ?>  
      </div>

    </div>
  </section><!-- End Services Section -->

  <!-- ======= Featured Services Section ======= -->
  <section id="gallery" class="featured-services" id="gallery">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
       <h2>Product</h2>
       <?php foreach ($konfigurasi as $konfig_product):?>
        <p class="textarea"><?php echo $konfig_product->product ?></p>
      </div>          
    <?php endforeach; ?>  
    <div class="row">    
      <?php foreach ($produk as $ss_produk):?>
        <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
          <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
            <div class="icon"><img class="img-fluid" src="<?= base_url('assets/brosur/').$ss_produk->brosur ?>"></div>
            <h4 class="title"><a href="<?php echo $ss_produk->link_produk ?>" target="_blank"><?php echo $ss_produk->nama_produk ?></a></h4>
            <p class="description"><?php echo character_limiter($ss_produk->deskripsi_produk, 50); ?></p>
          </div>
        </div>
      <?php endforeach; ?> 
    </div>

  </div>
</section><!-- End Featured Services Section -->

<!-- ======= patner Clients Section ======= -->
<section id="clients" class="clients section-bg">
  <div class="container" data-aos="zoom-in">
    <div class="section-title">
      <h2>Patner</h2>
    </div>
    <div class="row">
      <?php foreach ($patner as $patner):?>
        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
          <a href="<?php echo $patner->link_patner ?>"><img src="<?= base_url('assets/img/patner/').$patner->gambar_patner ?>" class="img-fluid"target="_blank"></a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="row"></div>
</section><!-- End Clients Section -->

<!-- ======= Testimonials Section ======= -->
<section id="testimonials" class="testimonials">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Testimoni</h2>
      <?php foreach ($konfigurasi as $konfig_testi):?>
        <p class="textarea"><?php echo $konfig_testi->testimoni ?></p>          
      <?php endforeach; ?>
    </div>

    <div class="owl-carousel testimonials-carousel" data-aos="fade-up" data-aos-delay="100">
     <?php foreach ($testi as $t):?>
      <div class="testimonial-item">
        <p>
          <i class="bx bxs-quote-alt-left quote-icon-left"></i>
          <?php echo $t->deskripsi_testi; ?>
          <i class="bx bxs-quote-alt-right quote-icon-right"></i>
        </p>
        <img src="<?= base_url('assets/img/foto_testi/').$t->foto_testi ?>" class="testimonial-img" alt="">
        <h3><?php echo $t->nama_testi; ?></h3>
        <h4><?php echo $t->pekerjaan; ?></h4>
      </div>
    <?php endforeach; ?>
  </div>
</div>
</section><!-- End Testimonials Section -->

<!-- ======= Team Section ======= -->
<section id="doctors" class="doctors section-bg">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Team</h2>
      <?php foreach ($konfigurasi as $konfig_team):?>
        <p class="textarea"><?php echo $konfig_team->team ?></p>          
      <?php endforeach; ?>
    </div>
    <div class="row">
      <?php foreach ($team as $team):?>
        <div class="col-lg-3 col-md-3 d-flex align-items-stretch">
          <div class="member" data-aos="fade-up" data-aos-delay="100">
            <div class="member-img">
              <div class="lingkaran1">
                <img src="<?php echo base_url('assets/img/'). $team->foto;?>" class="lingkaran1" alt="">
              </div>
              <div class="social">
                <a href="<?php echo $team->link_twiter; ?>"><i class="icofont-twitter"></i></a>
                <a href="<?php echo $team->link_facebook; ?>"><i class="icofont-facebook"></i></a>
                <a href="<?php echo $team->link_instagram; ?>"><i class="icofont-instagram"></i></a>
              </div>
            </div>
            <div class="member-info">
              <h4><?php echo $team->nama; ?></h4>
              <span><?php echo $team->role; ?></span>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section><!-- End Doctors Section -->

<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
  <div class="section-title">
    <h2>Contact</h2>
    <?php foreach ($konfigurasi as $konfig_contact):?>
      <p><?php echo $konfig_contact->contact ?></p>          
    <?php endforeach; ?>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="row">
          <?php foreach ($contact as $c):?>
            <div class="col-md-12">
              <div class="info-box">
                <i class="bx bx-map"></i>
                <h3>Alamat</h3>
                <p><?php echo $c->alamat; ?></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="info-box mt-4">
                <i class="bx bx-envelope"></i>
                <h3>Email Us</h3>
                <p><?php echo $c->email; ?></p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="info-box mt-4">
                <i class="bx bx-phone-call"></i>
                <h3>Tlp/WA</h3>
                <p><?php echo $c->telp; ?></p>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="col-lg-6">
        <form method="post" action="<?php echo base_url().'Home/add_tamu' ?>">
          <div class="form-row">
            <div class="col form-group">
              <input type="text" name="nama_tamu" class="form-control" id="nama_tamu" placeholder="Your Name" required />
              <input type="hidden" class="form-control"  name="tgl" required>
              <div class="validate"></div>
            </div>
            <div class="col form-group">
              <input type="email" class="form-control" name="email_tamu" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email"required />
              <div class="validate"></div>
            </div>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" required/>
            <div class="validate"></div>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="pesan" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="pesan"></textarea>
            <div class="validate"></div>
          </div>
          <button type="submit" class="btn btn-primary btn-icon-split btn-sm">
            <span class="icon text-white-50">
            </span>
            <span class="text">Send Messege</span>                       
          </button>
        </form>
      </div>
    </div>
  </div>
</section><!-- End Contact Section -->

</main>
<!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer">
  <div class="container">
    <div class="copyright">
      &copy; Copyright <span>DagangKita</span> <?php echo date('Y'); ?> Powered By <a href="https://play.google.com/store/apps/dev?id=6723590830928676626" target="_blank">Kreasi Anak Bengkalis</a>
    </div>
  </div>
</footer>
<!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/php-email-form/validate.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/counterup/counterup.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/venobox/venobox.min.js"></script>
<script src="<?php echo base_url() ?>assets/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="<?php echo base_url() ?>assets/js/main.js"></script>
<style type="text/css">
  .lingkaran1{
    width: 200px;
    height: 200px;
    background: #fff;
    border-radius: 100%;
  }
</style>

</body>

</html>