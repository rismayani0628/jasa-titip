<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('template/head_login');
?>
<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>Login</b></a>
  </div><!-- /.login-logo -->
  <div class="login-box-body">
   <?= $this->session->flashdata('pesan'); ?>
   <p class="login-box-msg">Silahkan Login</p>
   <form action="<?php base_url('Auth'); ?>" method="post">
     <?= form_error('username', '<small class="text-danger mb-3">', '</small>') ?>
     <div class="form-group has-feedback">
      <input type="username" name="username" class="form-control" placeholder="Username" value="<?php echo set_value('username'); ?>">
      <span class="glyphicon glyphicon-user form-control-feedback"></span>
    </div>
    <?= form_error('password', ' <small class="text-danger" pl-3>', '</small>'); ?>
    <div class="form-group has-feedback">
      <input type="password" class="form-control" placeholder="Password" name="password">
      <span class="glyphicon glyphicon-lock form-control-feedback "></span>
    </div>
    <center>
    <div class="row">
      <div class="col-xs-4">
      </div>
      <!-- /.col -->
     <div class="col-xs-4">
        <a href="<?php echo base_url('Home') ?>" class="btn btn-danger  btn-block btn-flat btn-sm">Kembali</a>
      </div>
      <div class="col-xs-4">
        <button type="submit" class="btn btn-primary btn-block btn-flat">Masuk</button>
      </div>
      <!-- /.col -->
    </div>
    </center>
  </form>
</div><!-- /.login-box-body -->
</div><!-- /.login-box -->
<?php $this->load->view('template/footer_login');?>