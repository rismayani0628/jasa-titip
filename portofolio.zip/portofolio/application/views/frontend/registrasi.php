<center>
  <div class="register-box">
    <div class="register-logo">
      <a href=""><b class="text-light text-bold">Registrasi</b></a>
    </div>
    <div class="card-body register-card-body">
      <p class="login-box-msg">Silahkan Registrasi Akun</p>
      <form class="registrasi" method="post" action="<?= base_url('Auth/registrasi'); ?>">
        <?= form_error('username', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="input-group mb-3">
          <input type="username" class="form-control" placeholder="username" name="username" value="<?= set_value('username');?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>

        <?= form_error('nama', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="input-group mb-3">
          <input type="nama" class="form-control" placeholder="Nama" name="nama" value="<?= set_value('nama');?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>

        <?= form_error('ttl', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="input-group mb-3">
          <input type="ttl" class="form-control" placeholder="Tempat Tanggal Lahir" name="ttl" value="<?= set_value('ttl');?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-calendar"></span>
            </div>
          </div>
        </div>

        <?= form_error('jk', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="row">
          <div class="input-group mb-3">
            <label class="col-2">Jk :</label>

            <div class="col-5">
              <div class="radio">
                <input type="radio" name="jk" value="P">
                <label for="jk"> Perempuan </label>
              </div>
            </div>

            <div class="col-5">
              <div class="radio">
                <input type="radio" name="jk" value="L">
                <label for="jk"> Laki-laki </label>
              </div>
            </div>
          </div>
        </div>

        <?= form_error('alamat', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="input-group mb-3">
          <input type="alamat" class="form-control" placeholder="Alamat Siswa" name="alamat" value="<?= set_value('alamat');?>">
          <div class="input-group-append">
            <div class="input-group-text">
            </div>
          </div>
        </div>

        <?= form_error('password1', '<small class="text-danger mb-3">', '</small>') ?>
        <div class="row">
          <div class="col-6">
           <div class="input-group mb-3">
            <input type="password" class="form-control" placeholder="Password" id="password1" name="password1">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
        </div>

        <!-- /.col -->
        <div class="col-6">
         <div class="input-group mb-3">
          <input type="password" class="form-control" placeholder="Ulangi Pass" name="password2" id="password2">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <div class="row">
      <div class="col-8">
      </div>
      <!-- /.col -->
      <div class="col-4">
        <button type="submit" class="btn btn-info btn-sm btn-block btn-flat ">Registrasi</button>
      </div>
      <!-- /.col -->
    </div>
  </form>
  <div class="text-left">
    <a href="<?php echo base_url('Auth')?>" class="text-center">Sudah punya akun? Login!</a>
  </div>
</div>
<!-- /.form-box -->
</div><!-- /.card -->
</div>
<!-- /.register-box -->